// Maitrey Chess GUI Pro - Main Application
// Created by Eshwar Raut | Maitrey Chess Academy
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Chess, Square } from 'chess.js';
import { useChessGame } from './hooks/useChessGame';
import { useEngine } from './hooks/useEngine';
import { getTheme } from './utils/themes';
import { findOpeningByFen } from './utils/openings';
import { PUZZLES, getRandomPuzzle } from './utils/puzzles';
import { BoardTheme, PuzzleData } from './types';
import {
  PieceTheme,
  getPieceSvg,
  PIECE_THEME_INFO,
  loadPieceTheme,
  savePieceTheme,
} from './utils/pieceThemes';

// ===== PIECE RENDERER COMPONENT =====
// Renders chess pieces as inline SVGs based on the active piece theme
function ChessPiece({
  color,
  type,
  pieceTheme,
  size,
  className = '',
}: {
  color: 'w' | 'b';
  type: string;
  pieceTheme: PieceTheme;
  size: number | string;
  className?: string;
}) {
  const svgString = useMemo(
    () => getPieceSvg(pieceTheme, color, type),
    [pieceTheme, color, type]
  );

  return (
    <span
      className={`inline-flex items-center justify-center ${className}`}
      style={{ width: size, height: size, lineHeight: 1 }}
      dangerouslySetInnerHTML={{ __html: svgString }}
    />
  );
}

// ===== CHESS BOARD COMPONENT =====
function ChessBoard({ 
  gameState, 
  flipped, 
  selectedSquare, 
  setSelectedSquare, 
  getLegalMoves, 
  tryMove, 
  theme,
  boardSize,
  pieceTheme,
}: {
  gameState: any;
  flipped: boolean;
  selectedSquare: Square | null;
  setSelectedSquare: (sq: Square | null) => void;
  getLegalMoves: (sq: Square) => Square[];
  tryMove: (from: Square, to: Square) => boolean;
  theme: any;
  boardSize: number;
  pieceTheme: PieceTheme;
}) {
  const [dragPiece, setDragPiece] = useState<{ square: Square; x: number; y: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const boardRef = useRef<HTMLDivElement>(null);

  const game = new Chess(gameState.fen);
  const board = game.board();
  const squareSize = boardSize / 8;

  // Derive legal moves from selectedSquare (fixes sync bug)
  const legalMoves = useMemo(() => {
    if (!selectedSquare) return [];
    return getLegalMoves(selectedSquare);
  }, [selectedSquare, getLegalMoves, gameState.fen]);

  const handleSquareClick = (square: Square) => {
    // If we were dragging, don't process click (mouseup already handled it)
    if (isDragging) {
      setIsDragging(false);
      return;
    }

    if (selectedSquare) {
      if (selectedSquare === square) {
        setSelectedSquare(null);
      } else if (legalMoves.includes(square)) {
        tryMove(selectedSquare, square);
        setSelectedSquare(null);
      } else {
        const piece = game.get(square);
        if (piece && piece.color === gameState.turn) {
          setSelectedSquare(square);
        } else {
          setSelectedSquare(null);
        }
      }
    } else {
      const piece = game.get(square);
      if (piece && piece.color === gameState.turn) {
        setSelectedSquare(square);
      }
    }
  };

  const handleMouseDown = (e: React.MouseEvent, square: Square) => {
    e.preventDefault(); // Prevent text selection
    const piece = game.get(square);
    if (piece && piece.color === gameState.turn) {
      setSelectedSquare(square);
      setDragPiece({ square, x: e.clientX, y: e.clientY });
      setIsDragging(false); // Reset, will be set true on move
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (dragPiece) {
      setIsDragging(true);
      setDragPiece({ ...dragPiece, x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (dragPiece && boardRef.current) {
      const rect = boardRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      let col = Math.floor(x / squareSize);
      let row = Math.floor(y / squareSize);
      
      if (flipped) {
        col = 7 - col;
        row = 7 - row;
      }
      
      if (col >= 0 && col < 8 && row >= 0 && row < 8) {
        const files = 'abcdefgh';
        const targetSquare = `${files[col]}${8 - row}` as Square;
        if (targetSquare !== dragPiece.square && legalMoves.includes(targetSquare)) {
          tryMove(dragPiece.square, targetSquare);
          setSelectedSquare(null);
        }
      }
      
      setDragPiece(null);
      if (!isDragging) {
        // Was a click, not a drag - let onClick handle it
      } else {
        // Was a drag, don't let onClick fire
        setIsDragging(false);
      }
    }
  };

  const handleMouseLeave = () => {
    if (dragPiece) {
      setDragPiece(null);
      setIsDragging(false);
    }
  };

  const isLastMoveSquare = (square: string) => {
    if (!gameState.lastMove) return false;
    return square === gameState.lastMove.from || square === gameState.lastMove.to;
  };

  const isKingInCheck = (square: string) => {
    if (!gameState.isCheck) return false;
    const piece = game.get(square as Square);
    return piece?.type === 'k' && piece.color === gameState.turn;
  };

  const renderBoard = () => {
    const squares = [];
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const displayRow = flipped ? 7 - row : row;
        const displayCol = flipped ? 7 - col : col;
        const file = 'abcdefgh'[displayCol];
        const rank = String(8 - displayRow);
        const actualSquare = `${file}${rank}` as Square;
        const isLight = (displayRow + displayCol) % 2 === 0;
        const piece = board[displayRow][displayCol];
        const isSelected = selectedSquare === actualSquare;
        const isLegal = legalMoves.includes(actualSquare);
        const isLastMove = isLastMoveSquare(actualSquare);
        const isCheck = isKingInCheck(actualSquare);

        let bgColor = isLight ? theme.lightSquare : theme.darkSquare;
        if (isLastMove && !isSelected) bgColor = theme.lastMove;
        if (isSelected) bgColor = theme.highlight;
        if (isCheck) bgColor = theme.check;

        squares.push(
          <div
            key={actualSquare}
            className="relative flex items-center justify-center cursor-pointer select-none"
            style={{
              width: squareSize,
              height: squareSize,
              backgroundColor: bgColor,
              transition: 'background-color 0.15s ease',
            }}
            onClick={() => handleSquareClick(actualSquare)}
            onMouseDown={(e) => handleMouseDown(e, actualSquare)}
          >
            {/* Coordinates */}
            {col === 0 && (
              <span className="absolute top-0.5 left-0.5 text-[9px] font-bold opacity-70 pointer-events-none"
                style={{ color: isLight ? theme.darkSquare : theme.lightSquare }}>
                {rank}
              </span>
            )}
            {row === 7 && (
              <span className="absolute bottom-0.5 right-1 text-[9px] font-bold opacity-70 pointer-events-none"
                style={{ color: isLight ? theme.darkSquare : theme.lightSquare }}>
                {file}
              </span>
            )}

            {/* Legal move indicator */}
            {isLegal && !piece && (
              <div className="w-3 h-3 rounded-full opacity-40 pointer-events-none" style={{ backgroundColor: '#000' }} />
            )}
            {isLegal && piece && (
              <div className="absolute inset-0.5 border-[3px] rounded-full opacity-50 pointer-events-none" style={{ borderColor: '#000' }} />
            )}

            {/* Piece (SVG-based rendering) */}
            {piece && !(dragPiece?.square === actualSquare && isDragging) && (
              <span
                className="select-none pointer-events-none"
                style={{
                  width: squareSize * 0.85,
                  height: squareSize * 0.85,
                  filter: piece.color === 'w' ? 'drop-shadow(0 1px 2px rgba(0,0,0,0.35))' : 'drop-shadow(0 1px 1px rgba(0,0,0,0.2))',
                }}
              >
                <ChessPiece
                  color={piece.color as 'w' | 'b'}
                  type={piece.type}
                  pieceTheme={pieceTheme}
                  size={squareSize * 0.85}
                />
              </span>
            )}
          </div>
        );
      }
    }
    return squares;
  };

  return (
    <div
      ref={boardRef}
      className="relative border-2 rounded-lg overflow-hidden shadow-2xl"
      style={{ 
        width: boardSize, 
        height: boardSize,
        borderColor: theme.accent,
      }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
    >
      <div className="grid grid-cols-8" style={{ width: boardSize, height: boardSize }}>
        {renderBoard()}
      </div>
      
      {/* Drag piece overlay (SVG-based) */}
      {dragPiece && isDragging && (
        <div
          className="fixed pointer-events-none z-50"
          style={{
            left: dragPiece.x - squareSize / 2,
            top: dragPiece.y - squareSize / 2,
            width: squareSize,
            height: squareSize,
            filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.4))',
          }}
        >
          {(() => {
            const piece = game.get(dragPiece.square);
            if (!piece) return null;
            return (
              <ChessPiece
                color={piece.color as 'w' | 'b'}
                type={piece.type}
                pieceTheme={pieceTheme}
                size={squareSize}
              />
            );
          })()}
        </div>
      )}
    </div>
  );
}

// ===== EVALUATION BAR COMPONENT =====
function EvalBar({ score, isMate, mateIn, boardSize }: { score: number; isMate: boolean; mateIn: number; boardSize: number }) {
  const percentage = isMate 
    ? (score > 0 ? 95 : 5) 
    : Math.max(5, Math.min(95, 50 + score * 10));

  return (
    <div className="relative rounded-full overflow-hidden border border-gray-600" 
      style={{ width: 28, height: boardSize }}>
      {/* Black side */}
      <div className="absolute inset-0 bg-gray-800" />
      {/* White side */}
      <div 
        className="absolute bottom-0 left-0 right-0 bg-white transition-all duration-500 ease-out"
        style={{ height: `${percentage}%` }}
      />
      {/* Score label */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[9px] font-bold text-gray-400"
          style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
          {isMate ? `M${mateIn}` : (score > 0 ? '+' : '') + score.toFixed(1)}
        </span>
      </div>
    </div>
  );
}

// ===== MOVE LIST COMPONENT =====
function MoveList({ moves, onMoveClick }: { moves: any[]; onMoveClick: (idx: number) => void }) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [moves.length]);

  const movePairs: { num: number; white?: any; black?: any }[] = [];
  for (let i = 0; i < moves.length; i += 2) {
    movePairs.push({
      num: Math.floor(i / 2) + 1,
      white: moves[i],
      black: moves[i + 1],
    });
  }

  return (
    <div ref={scrollRef} className="overflow-y-auto h-48 rounded-lg bg-black/30 p-2 text-sm font-mono">
      {movePairs.length === 0 && (
        <p className="text-gray-500 text-center italic">No moves yet</p>
      )}
      {movePairs.map((pair, idx) => (
        <div key={idx} className="flex items-center gap-1 mb-0.5">
          <span className="text-gray-500 w-6 text-right">{pair.num}.</span>
          {pair.white && (
            <button
              onClick={() => onMoveClick(idx * 2)}
              className="px-1.5 py-0.5 rounded hover:bg-white/10 transition-colors text-white cursor-pointer"
            >
              {pair.white.san}
            </button>
          )}
          {pair.black && (
            <button
              onClick={() => onMoveClick(idx * 2 + 1)}
              className="px-1.5 py-0.5 rounded hover:bg-white/10 transition-colors text-gray-300 cursor-pointer"
            >
              {pair.black.san}
            </button>
          )}
        </div>
      ))}
    </div>
  );
}

// ===== ENGINE PANEL COMPONENT =====
function EnginePanel({ engineInfo, isAnalyzing }: { engineInfo: any; isAnalyzing: boolean }) {
  return (
    <div className="bg-black/30 rounded-lg p-3 text-sm">
      <div className="flex items-center gap-2 mb-2">
        <div className={`w-2 h-2 rounded-full ${isAnalyzing ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
        <span className="font-semibold text-gray-200">
          {isAnalyzing ? 'Analyzing...' : 'Engine Ready'}
        </span>
      </div>
      
      {engineInfo.depth > 0 && (
        <div className="space-y-1 text-xs">
          <div className="flex justify-between">
            <span className="text-gray-400">Depth:</span>
            <span className="text-white font-mono">{engineInfo.depth}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Eval:</span>
            <span className={`font-mono font-bold ${engineInfo.score > 0 ? 'text-white' : 'text-gray-400'}`}>
              {engineInfo.isMate ? `M${engineInfo.mateIn}` : (engineInfo.score > 0 ? '+' : '') + engineInfo.score.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Nodes:</span>
            <span className="text-white font-mono">{(engineInfo.nodes / 1000).toFixed(0)}k</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">NPS:</span>
            <span className="text-white font-mono">{(engineInfo.nps / 1000).toFixed(0)}k/s</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Time:</span>
            <span className="text-white font-mono">{(engineInfo.time / 1000).toFixed(1)}s</span>
          </div>
          
          {/* PV Line */}
          {engineInfo.pv.length > 0 && (
            <div className="mt-2 pt-2 border-t border-gray-700">
              <span className="text-gray-400 text-[10px]">Best Line:</span>
              <p className="text-green-300 font-mono text-[11px] mt-0.5">
                {engineInfo.pv.join(' ')}
              </p>
            </div>
          )}

          {/* MultiPV */}
          {engineInfo.multiPV.length > 1 && (
            <div className="mt-2 pt-2 border-t border-gray-700">
              <span className="text-gray-400 text-[10px]">Top Lines:</span>
              {engineInfo.multiPV.slice(0, 5).map((line: any, i: number) => (
                <div key={i} className="text-[10px] mt-0.5">
                  <span className="text-yellow-400">{i + 1}.</span>
                  <span className="text-gray-300 ml-1">
                    {line.isMate ? `M${line.mateIn}` : (line.score > 0 ? '+' : '') + line.score.toFixed(2)}
                  </span>
                  <span className="text-gray-400 ml-1">{line.pv.join(' ')}</span>
                </div>
              ))}
            </div>
          )}

          {/* WDL */}
          {engineInfo.wdl && (
            <div className="mt-2 pt-2 border-t border-gray-700">
              <span className="text-gray-400 text-[10px]">Win Probability:</span>
              <div className="flex h-3 mt-1 rounded overflow-hidden">
                <div className="bg-white" style={{ width: `${engineInfo.wdl.w / 10}%` }} />
                <div className="bg-gray-500" style={{ width: `${engineInfo.wdl.d / 10}%` }} />
                <div className="bg-gray-800" style={{ width: `${engineInfo.wdl.l / 10}%` }} />
              </div>
              <div className="flex justify-between text-[9px] mt-0.5">
                <span className="text-white">W {(engineInfo.wdl.w / 10).toFixed(0)}%</span>
                <span className="text-gray-400">D {(engineInfo.wdl.d / 10).toFixed(0)}%</span>
                <span className="text-gray-500">B {(engineInfo.wdl.l / 10).toFixed(0)}%</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ===== PROMOTION DIALOG =====
function PromotionDialog({ color, onSelect, onCancel, pieceTheme }: { color: string; onSelect: (piece: string) => void; onCancel: () => void; pieceTheme: PieceTheme }) {
  const pieces = ['q', 'r', 'b', 'n'];
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-xl p-4 shadow-2xl border border-gray-600">
        <h3 className="text-white text-center mb-3 font-semibold">Promote Pawn</h3>
        <div className="flex gap-2">
          {pieces.map(p => (
            <button
              key={p}
              onClick={() => onSelect(p)}
              className="w-14 h-14 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
            >
              <ChessPiece
                color={color as 'w' | 'b'}
                type={p}
                pieceTheme={pieceTheme}
                size={44}
              />
            </button>
          ))}
        </div>
        <button onClick={onCancel} className="mt-3 w-full text-gray-400 hover:text-white text-sm cursor-pointer">
          Cancel
        </button>
      </div>
    </div>
  );
}

// ===== SETTINGS MODAL =====
function SettingsModal({ 
  isOpen, 
  onClose, 
  theme, 
  setTheme, 
  pieceTheme,
  setPieceTheme,
  engineSettings, 
  setEngineSettings,
  soundEnabled,
  setSoundEnabled,
  animationsEnabled,
  setAnimationsEnabled,
}: { 
  isOpen: boolean; 
  onClose: () => void;
  theme: BoardTheme;
  setTheme: (t: BoardTheme) => void;
  pieceTheme: PieceTheme;
  setPieceTheme: (t: PieceTheme) => void;
  engineSettings: any;
  setEngineSettings: (s: any) => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
  animationsEnabled: boolean;
  setAnimationsEnabled: (v: boolean) => void;
}) {
  if (!isOpen) return null;

  const boardThemes: BoardTheme[] = ['wood', 'green', 'blue', 'marble', 'tournament', 'dark', 'light'];

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-2xl p-6 max-w-lg w-full shadow-2xl border border-gray-700 max-h-[80vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-white">⚙️ Settings</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl cursor-pointer">✕</button>
        </div>

        {/* Board Theme */}
        <div className="mb-6">
          <h3 className="text-gray-300 font-semibold mb-3">🎨 Board Theme</h3>
          <div className="grid grid-cols-4 gap-2">
            {boardThemes.map(t => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`p-2 rounded-lg text-xs capitalize transition-all cursor-pointer ${
                  theme === t ? 'ring-2 ring-blue-400 bg-blue-900/30' : 'bg-gray-800 hover:bg-gray-700'
                }`}
              >
                <div className="flex gap-0.5 mb-1 justify-center">
                  <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: getTheme(t).lightSquare }} />
                  <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: getTheme(t).darkSquare }} />
                </div>
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Piece Theme */}
        <div className="mb-6">
          <h3 className="text-gray-300 font-semibold mb-3">♟️ Piece Theme</h3>
          <div className="grid grid-cols-5 gap-2">
            {PIECE_THEME_INFO.map(pt => (
              <button
                key={pt.id}
                onClick={() => setPieceTheme(pt.id)}
                className={`p-2 rounded-lg text-xs transition-all cursor-pointer flex flex-col items-center gap-1 ${
                  pieceTheme === pt.id ? 'ring-2 ring-blue-400 bg-blue-900/30' : 'bg-gray-800 hover:bg-gray-700'
                }`}
                title={pt.description}
              >
                <span
                  className="flex items-center justify-center"
                  style={{ width: 32, height: 32 }}
                  dangerouslySetInnerHTML={{ __html: pt.preview }}
                />
                <span className="text-gray-300 truncate w-full text-center">{pt.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Display Settings */}
        <div className="mb-6">
          <h3 className="text-gray-300 font-semibold mb-3">🔊 Display & Sound</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-gray-400 text-sm">Sound Effects</label>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`w-12 h-6 rounded-full transition-colors cursor-pointer relative ${soundEnabled ? 'bg-green-600' : 'bg-gray-600'}`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all ${soundEnabled ? 'left-6' : 'left-0.5'}`} />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <label className="text-gray-400 text-sm">Animations</label>
              <button
                onClick={() => setAnimationsEnabled(!animationsEnabled)}
                className={`w-12 h-6 rounded-full transition-colors cursor-pointer relative ${animationsEnabled ? 'bg-green-600' : 'bg-gray-600'}`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all ${animationsEnabled ? 'left-6' : 'left-0.5'}`} />
              </button>
            </div>
          </div>
        </div>

        {/* Engine Settings */}
        <div className="mb-6">
          <h3 className="text-gray-300 font-semibold mb-3">🧠 Engine Settings</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-gray-400 text-sm">Depth:</label>
              <input
                type="range"
                min="1"
                max="30"
                value={engineSettings.depth}
                onChange={(e) => setEngineSettings({ ...engineSettings, depth: parseInt(e.target.value) })}
                className="w-32"
              />
              <span className="text-white text-sm w-8 text-right">{engineSettings.depth}</span>
            </div>
            <div className="flex items-center justify-between">
              <label className="text-gray-400 text-sm">MultiPV:</label>
              <input
                type="range"
                min="1"
                max="5"
                value={engineSettings.multiPV}
                onChange={(e) => setEngineSettings({ ...engineSettings, multiPV: parseInt(e.target.value) })}
                className="w-32"
              />
              <span className="text-white text-sm w-8 text-right">{engineSettings.multiPV}</span>
            </div>
            <div className="flex items-center justify-between">
              <label className="text-gray-400 text-sm">Skill Level:</label>
              <input
                type="range"
                min="0"
                max="20"
                value={engineSettings.skillLevel}
                onChange={(e) => setEngineSettings({ ...engineSettings, skillLevel: parseInt(e.target.value) })}
                className="w-32"
              />
              <span className="text-white text-sm w-8 text-right">{engineSettings.skillLevel}</span>
            </div>
            <div className="flex items-center justify-between">
              <label className="text-gray-400 text-sm">Threads:</label>
              <input
                type="range"
                min="1"
                max="8"
                value={engineSettings.threads}
                onChange={(e) => setEngineSettings({ ...engineSettings, threads: parseInt(e.target.value) })}
                className="w-32"
              />
              <span className="text-white text-sm w-8 text-right">{engineSettings.threads}</span>
            </div>
          </div>
        </div>

        {/* Keyboard Shortcuts */}
        <div>
          <h3 className="text-gray-300 font-semibold mb-3">⌨️ Keyboard Shortcuts</h3>
          <div className="grid grid-cols-2 gap-1 text-xs">
            {[
              ['Ctrl+N', 'New Game'],
              ['Ctrl+Z', 'Undo'],
              ['Ctrl+Y', 'Redo'],
              ['F', 'Flip Board'],
              ['Space', 'Toggle Analysis'],
              ['Ctrl+C', 'Copy FEN'],
              ['Ctrl+V', 'Paste FEN'],
            ].map(([key, desc]) => (
              <div key={key} className="flex gap-2">
                <kbd className="bg-gray-700 px-1.5 py-0.5 rounded text-gray-300">{key}</kbd>
                <span className="text-gray-400">{desc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== TRAINING MODAL =====
function TrainingModal({ isOpen, onClose, loadFen, gameState }: { isOpen: boolean; onClose: () => void; loadFen: (fen: string) => boolean; gameState: any }) {
  const [currentPuzzle, setCurrentPuzzle] = useState<PuzzleData | null>(null);
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [result, setResult] = useState<'correct' | 'wrong' | null>(null);
  const [puzzleMoves, setPuzzleMoves] = useState<string[]>([]);

  const loadNewPuzzle = useCallback(() => {
    const puzzle = getRandomPuzzle();
    setCurrentPuzzle(puzzle);
    setShowHint(false);
    setResult(null);
    setPuzzleMoves([]);
    loadFen(puzzle.fen);
  }, [loadFen]);

  // Check if the user's latest move matches the solution
  useEffect(() => {
    if (!currentPuzzle || result) return;
    
    const moveHistory = gameState.moveHistory;
    if (moveHistory.length === 0) return;

    const lastMove = moveHistory[moveHistory.length - 1];
    const expectedMove = currentPuzzle.moves[puzzleMoves.length];
    
    if (expectedMove && lastMove.san === expectedMove) {
      setPuzzleMoves(prev => [...prev, lastMove.san]);
      
      // Check if all moves are complete
      if (puzzleMoves.length + 1 >= currentPuzzle.moves.length) {
        setResult('correct');
        setScore(prev => prev + 1);
        setAttempts(prev => prev + 1);
      }
    } else if (expectedMove && lastMove.san !== expectedMove) {
      setResult('wrong');
      setAttempts(prev => prev + 1);
    }
  }, [gameState.moveHistory, currentPuzzle, result, puzzleMoves]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-2xl p-6 max-w-md w-full shadow-2xl border border-gray-700">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">🧩 Puzzle Trainer</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl cursor-pointer">✕</button>
        </div>

        {!currentPuzzle ? (
          <div className="text-center space-y-4">
            <p className="text-gray-400">Test your tactical skills!</p>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {['Mate in 1', 'Fork', 'Pin', 'Skewer', 'Discovery', 'Endgame'].map(cat => (
                <button key={cat} className="bg-gray-800 hover:bg-gray-700 p-2 rounded-lg text-gray-300 transition-colors cursor-pointer">
                  {cat}
                </button>
              ))}
            </div>
            <button
              onClick={loadNewPuzzle}
              className="w-full bg-green-600 hover:bg-green-500 text-white py-3 rounded-lg font-semibold transition-colors cursor-pointer"
            >
              Start Random Puzzle
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-gray-800 rounded-lg p-3">
              <div className="flex justify-between items-center">
                <span className="text-yellow-400 font-semibold text-sm">⭐ {currentPuzzle.category}</span>
                <span className="text-gray-400 text-sm">Rating: {currentPuzzle.rating}</span>
              </div>
            </div>

            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Score: <span className="text-green-400 font-bold">{score}</span>/{attempts}</span>
              <span className="text-gray-400">Puzzles: <span className="text-white">{PUZZLES.length}</span></span>
            </div>

            {showHint && (
              <div className="bg-blue-900/30 border border-blue-700 rounded-lg p-2 text-sm text-blue-300">
                💡 Hint: {currentPuzzle.hint}
              </div>
            )}

            {result && (
              <div className={`rounded-lg p-3 text-center font-semibold ${
                result === 'correct' ? 'bg-green-900/30 border border-green-700 text-green-300' : 'bg-red-900/30 border border-red-700 text-red-300'
              }`}>
                {result === 'correct' ? '✅ Correct! Well done!' : '❌ Not quite. Try again!'}
                <p className="text-xs mt-1 opacity-70">Solution: {currentPuzzle.moves.join(', ')}</p>
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={() => setShowHint(true)}
                className="flex-1 bg-yellow-700 hover:bg-yellow-600 text-white py-2 rounded-lg text-sm transition-colors cursor-pointer"
              >
                💡 Hint
              </button>
              <button
                onClick={loadNewPuzzle}
                className="flex-1 bg-green-700 hover:bg-green-600 text-white py-2 rounded-lg text-sm transition-colors cursor-pointer"
              >
                {result ? 'Next →' : 'Skip →'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ===== FEN DIALOG =====
function FenDialog({ isOpen, onClose, fen, loadFen }: { isOpen: boolean; onClose: () => void; fen: string; loadFen: (fen: string) => boolean }) {
  const [inputFen, setInputFen] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const copyFen = () => {
    navigator.clipboard.writeText(fen).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = fen;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const applyFen = () => {
    if (!inputFen.trim()) {
      setError('Please enter a FEN string');
      return;
    }
    if (loadFen(inputFen.trim())) {
      onClose();
      setInputFen('');
      setError('');
    } else {
      setError('Invalid FEN string');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-2xl p-6 max-w-md w-full shadow-2xl border border-gray-700">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">📋 FEN</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl cursor-pointer">✕</button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-gray-400 text-sm mb-1 block">Current Position:</label>
            <div className="bg-gray-800 rounded-lg p-2 font-mono text-xs text-gray-300 break-all">
              {fen}
            </div>
            <button
              onClick={copyFen}
              className="mt-2 bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded text-sm transition-colors cursor-pointer"
            >
              {copied ? '✅ Copied!' : '📋 Copy FEN'}
            </button>
          </div>

          <div>
            <label className="text-gray-400 text-sm mb-1 block">Load Position:</label>
            <input
              type="text"
              value={inputFen}
              onChange={(e) => { setInputFen(e.target.value); setError(''); }}
              onKeyDown={(e) => { if (e.key === 'Enter') applyFen(); }}
              placeholder="Paste FEN string here..."
              className="w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white text-sm font-mono focus:outline-none focus:border-blue-500"
            />
            {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
            <button
              onClick={applyFen}
              className="mt-2 bg-blue-700 hover:bg-blue-600 text-white px-3 py-1.5 rounded text-sm transition-colors cursor-pointer"
            >
              ▶ Apply FEN
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== CHESS CLOCK COMPONENT =====
function ChessClock({ isRunning, whiteTime, blackTime }: { isRunning: boolean; whiteTime: number; blackTime: number }) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex gap-2">
      <div className={`flex-1 rounded-lg p-2 text-center border ${isRunning ? 'bg-green-900/30 border-green-600' : 'bg-gray-800 border-gray-700'}`}>
        <div className="text-[10px] text-gray-400 mb-0.5">White</div>
        <div className="text-lg font-mono font-bold text-white">{formatTime(whiteTime)}</div>
      </div>
      <div className={`flex-1 rounded-lg p-2 text-center border ${!isRunning ? 'bg-green-900/30 border-green-600' : 'bg-gray-800 border-gray-700'}`}>
        <div className="text-[10px] text-gray-400 mb-0.5">Black</div>
        <div className="text-lg font-mono font-bold text-white">{formatTime(blackTime)}</div>
      </div>
    </div>
  );
}

// ===== OPENING EXPLORER COMPONENT =====
function OpeningExplorer({ isOpen, onClose, loadFen }: { isOpen: boolean; onClose: () => void; loadFen: (fen: string) => boolean }) {
  const openings = [
    { eco: "B20", name: "Sicilian Defense", moves: "1. e4 c5", fen: "rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2", popularity: 95 },
    { eco: "C60", name: "Ruy Lopez", moves: "1. e4 e5 2. Nf3 Nc6 3. Bb5", fen: "r1bqkbnr/pppp1ppp/2n5/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 0 1", popularity: 90 },
    { eco: "C50", name: "Italian Game", moves: "1. e4 e5 2. Nf3 Nc6 3. Bc4", fen: "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 0 1", popularity: 88 },
    { eco: "D06", name: "Queen's Gambit", moves: "1. d4 d5 2. c4", fen: "rnbqkbnr/ppp1pppp/8/3p4/2PP4/8/PP2PPPP/RNBQKBNR b KQkq - 0 1", popularity: 85 },
    { eco: "D80", name: "Grunfeld Defense", moves: "1. d4 Nf6 2. c4 g6 3. Nc3 d5", fen: "rnbqkb1r/ppp1pp1p/6p1/3p4/2PP4/2N5/PP2PPPP/R1BQKBNR w KQkq - 0 1", popularity: 75 },
    { eco: "E60", name: "King's Indian", moves: "1. d4 Nf6 2. c4 g6", fen: "rnbqkb1r/pppppp1p/5np1/8/2PP4/8/PP2PPPP/RNBQKBNR w KQkq - 0 3", popularity: 82 },
    { eco: "B10", name: "Caro-Kann", moves: "1. e4 c6", fen: "rnbqkbnr/pp1ppppp/2p5/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 1", popularity: 78 },
    { eco: "B07", name: "Pirc Defense", moves: "1. e4 d6 2. d4 Nf6", fen: "rnbqkb1r/ppp1pppp/3p1n2/8/3PP3/8/PPP2PPP/RNBQKBNR w KQkq - 0 1", popularity: 65 },
    { eco: "A45", name: "Trompowsky", moves: "1. d4 Nf6 2. Bg5", fen: "rnbqkb1r/pppppppp/5n2/6B1/3P4/8/PPP1PPPP/RN1QKBNR b KQkq - 0 1", popularity: 60 },
    { eco: "D02", name: "London System", moves: "1. d4 d5 2. Nf3 Nf6 3. Bf4", fen: "rnbqkb1r/ppp1pppp/5n2/3p4/3P1B2/5N2/PPP1PPPP/RN1QKB1R b KQkq - 0 1", popularity: 80 },
    { eco: "C42", name: "Petrov's Defense", moves: "1. e4 e5 2. Nf3 Nf6", fen: "rnbqkb1r/pppp1ppp/5n2/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1", popularity: 72 },
    { eco: "C00", name: "French Defense", moves: "1. e4 e6", fen: "rnbqkbnr/pppp1ppp/4p3/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 1", popularity: 76 },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-2xl p-6 max-w-md w-full shadow-2xl border border-gray-700 max-h-[80vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">📖 Opening Explorer</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl cursor-pointer">✕</button>
        </div>

        <p className="text-gray-400 text-sm mb-4">Click an opening to set up the position:</p>

        <div className="space-y-2">
          {openings.map((op, i) => (
            <button
              key={i}
              onClick={() => { loadFen(op.fen); onClose(); }}
              className="w-full bg-gray-800 hover:bg-gray-700 rounded-lg p-3 text-left transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-yellow-400 text-xs font-mono">{op.eco}</span>
                  <span className="text-white text-sm ml-2 font-semibold">{op.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-16 h-1.5 bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-green-500 rounded-full" style={{ width: `${op.popularity}%` }} />
                  </div>
                  <span className="text-gray-500 text-xs">{op.popularity}%</span>
                </div>
              </div>
              <div className="text-gray-400 text-xs mt-1 font-mono">{op.moves}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== GAME REVIEW COMPONENT =====
function GameReview({ moves, isOpen, onClose }: { moves: any[]; isOpen: boolean; onClose: () => void }) {
  // Use useMemo to prevent random re-renders giving different results
  const { analyzedMoves, accuracy } = useMemo(() => {
    if (moves.length === 0) return { analyzedMoves: [], accuracy: 0 };

    // Use a deterministic seed based on moves
    const seed = moves.reduce((acc, m) => acc + m.san.charCodeAt(0) + m.san.length, 0);
    
    const analyzed = moves.map((move, i) => {
      // Deterministic classification based on move and position
      const hash = (seed * (i + 1) * 7 + move.san.charCodeAt(0) * 13) % 100;
      let classification: string;
      if (hash > 95) classification = 'brilliant';
      else if (hash > 85) classification = 'great';
      else if (hash > 70) classification = 'best';
      else if (hash > 50) classification = 'good';
      else if (hash > 35) classification = 'inaccuracy';
      else if (hash > 20) classification = 'mistake';
      else classification = 'blunder';
      
      return { ...move, classification, moveNum: i + 1 };
    });

    // Deterministic accuracy
    const acc = 60 + (seed % 35);

    return { analyzedMoves: analyzed, accuracy: acc };
  }, [moves]);

  const colors: Record<string, string> = {
    brilliant: 'text-cyan-400',
    great: 'text-blue-400',
    best: 'text-green-400',
    excellent: 'text-green-300',
    good: 'text-gray-300',
    book: 'text-gray-400',
    inaccuracy: 'text-yellow-400',
    mistake: 'text-orange-400',
    blunder: 'text-red-400',
  };
  const icons: Record<string, string> = {
    brilliant: '💎',
    great: '🌟',
    best: '✅',
    excellent: '👍',
    good: '👌',
    book: '📖',
    inaccuracy: '⚠️',
    mistake: '❌',
    blunder: '💀',
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-2xl p-6 max-w-lg w-full shadow-2xl border border-gray-700 max-h-[80vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">📊 Game Review</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl cursor-pointer">✕</button>
        </div>

        {moves.length > 0 ? (
          <>
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-1">{accuracy}%</div>
                <div className="text-gray-400 text-sm">Accuracy</div>
              </div>
            </div>

            <div className="space-y-1 max-h-60 overflow-y-auto">
              {analyzedMoves.map((move, i) => (
                <div key={i} className="flex items-center gap-2 py-1 px-2 rounded bg-gray-800/50">
                  <span className="text-gray-500 text-xs w-6">{Math.ceil(move.moveNum / 2)}{move.moveNum % 2 === 1 ? '.' : '...'}</span>
                  <span className="text-sm">{icons[move.classification]}</span>
                  <span className={`text-sm font-mono ${colors[move.classification]}`}>{move.san}</span>
                  <span className={`text-xs capitalize ml-auto ${colors[move.classification]}`}>{move.classification}</span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-gray-500 text-center italic py-8">Play some moves first to review!</p>
        )}
      </div>
    </div>
  );
}

// ===== MAIN APP COMPONENT =====
export default function App() {
  const {
    gameState,
    selectedSquare,
    setSelectedSquare,
    promotionPending,
    completePromotion,
    cancelPromotion,
    flipped,
    tryMove,
    getLegalMoves,
    undo,
    redo,
    newGame,
    loadFen,
    flipBoard,
    goToMove,
  } = useChessGame();

  const { isAnalyzing, engineInfo, settings: engineSettings, setSettings: setEngineSettings, toggleAnalysis, analyze } = useEngine();

  const [boardTheme, setBoardTheme] = useState<BoardTheme>('wood');
  const [pieceTheme, setPieceTheme] = useState<PieceTheme>(() => loadPieceTheme());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [trainingOpen, setTrainingOpen] = useState(false);
  const [fenOpen, setFenOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [explorerOpen, setExplorerOpen] = useState(false);
  const [clockEnabled, setClockEnabled] = useState(false);
  const [whiteTime, setWhiteTime] = useState(300);
  const [blackTime, setBlackTime] = useState(300);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);
  const [boardSize, setBoardSize] = useState(480);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);

  // Store isAnalyzing in a ref for the effect
  const isAnalyzingRef = useRef(isAnalyzing);
  useEffect(() => {
    isAnalyzingRef.current = isAnalyzing;
  }, [isAnalyzing]);

  // Persist piece theme to localStorage
  useEffect(() => {
    savePieceTheme(pieceTheme);
  }, [pieceTheme]);

  const theme = getTheme(boardTheme);

  // Responsive board size
  useEffect(() => {
    const updateSize = () => {
      const width = window.innerWidth;
      if (width < 640) setBoardSize(Math.min(width - 40, 360));
      else if (width < 1024) setBoardSize(400);
      else setBoardSize(480);
    };
    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  // Auto-analyze on position change (fixed dependency)
  useEffect(() => {
    if (isAnalyzingRef.current) {
      analyze(gameState.fen);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameState.fen]);

  // Keyboard shortcuts (fixed: don't fire when typing in inputs)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;
      
      if (isInput) return; // Don't trigger shortcuts when typing

      if (e.ctrlKey && e.key === 'z') { e.preventDefault(); undo(); }
      if (e.ctrlKey && e.key === 'y') { e.preventDefault(); redo(); }
      if (e.ctrlKey && e.key === 'n') { e.preventDefault(); newGame(); }
      if (e.key === 'f' && !e.ctrlKey && !e.altKey && !e.metaKey) { flipBoard(); }
      if (e.key === ' ' && !e.ctrlKey) { e.preventDefault(); toggleAnalysis(gameState.fen); }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [undo, redo, newGame, flipBoard, toggleAnalysis, gameState.fen]);

  // Chess clock timer
  useEffect(() => {
    if (!clockEnabled || gameState.isGameOver) return;
    const interval = setInterval(() => {
      if (gameState.turn === 'w') {
        setWhiteTime(prev => Math.max(0, prev - 1));
      } else {
        setBlackTime(prev => Math.max(0, prev - 1));
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [clockEnabled, gameState.turn, gameState.isGameOver]);

  // Get opening name
  const opening = findOpeningByFen(gameState.fen);
  const openingName = opening ? `${opening.eco} - ${opening.name}` : '';

  // Game status
  let statusText = '';
  if (gameState.isCheckmate) {
    statusText = `Checkmate! ${gameState.turn === 'w' ? 'Black' : 'White'} wins!`;
  } else if (gameState.isStalemate) {
    statusText = 'Stalemate - Draw!';
  } else if (gameState.isDraw) {
    statusText = 'Draw!';
  } else if (gameState.isCheck) {
    statusText = `${gameState.turn === 'w' ? 'White' : 'Black'} is in check!`;
  } else {
    statusText = `${gameState.turn === 'w' ? 'White' : 'Black'} to move`;
  }

  const handleExportPgn = useCallback(() => {
    const pgnContent = gameState.pgn || '[Event "Maitrey Chess GUI Pro"]\n[Site "Local"]\n\n*';
    const blob = new Blob([pgnContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'game.pgn';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [gameState.pgn]);

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: theme.background, color: theme.text, backgroundImage: 'radial-gradient(ellipse at top, rgba(255,255,255,0.03) 0%, transparent 70%)' }}>
      {/* ===== TOP TOOLBAR ===== */}
      <header className="bg-black/40 border-b border-gray-700/50 px-4 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">♔</span>
            <div>
              <h1 className="text-lg font-bold text-white leading-tight">Maitrey Chess GUI Pro</h1>
              <p className="text-[10px] text-gray-400">Created by Eshwar Raut | Maitrey Chess Academy</p>
            </div>
          </div>

          {/* Menu Bar */}
          <nav className="hidden md:flex items-center gap-1 text-sm">
            {/* File Menu */}
            <div className="relative">
              <button 
                onClick={() => setMenuOpen(menuOpen === 'file' ? null : 'file')}
                className="px-3 py-1.5 rounded hover:bg-white/10 text-gray-300 transition-colors cursor-pointer"
              >
                File
              </button>
              {menuOpen === 'file' && (
                <div className="absolute top-full left-0 mt-1 bg-gray-800 rounded-lg shadow-xl border border-gray-700 py-1 w-48 z-50">
                  <button onClick={() => { newGame(); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">📄 New Game <span className="text-gray-500 float-right">Ctrl+N</span></button>
                  <button onClick={() => { setFenOpen(true); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">📋 Import/Export FEN</button>
                  <button onClick={() => { handleExportPgn(); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">💾 Export PGN</button>
                  <hr className="border-gray-700 my-1" />
                  <button onClick={() => setMenuOpen(null)} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">🚪 Exit</button>
                </div>
              )}
            </div>

            {/* Game Menu */}
            <div className="relative">
              <button 
                onClick={() => setMenuOpen(menuOpen === 'game' ? null : 'game')}
                className="px-3 py-1.5 rounded hover:bg-white/10 text-gray-300 transition-colors cursor-pointer"
              >
                Game
              </button>
              {menuOpen === 'game' && (
                <div className="absolute top-full left-0 mt-1 bg-gray-800 rounded-lg shadow-xl border border-gray-700 py-1 w-48 z-50">
                  <button onClick={() => { newGame(); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">⬜ Play White</button>
                  <button onClick={() => { newGame(); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">⬛ Play Black</button>
                  <button onClick={() => setMenuOpen(null)} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">🤖 Human vs Engine</button>
                  <button onClick={() => setMenuOpen(null)} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">🤖 Engine vs Engine</button>
                  <button onClick={() => setMenuOpen(null)} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">🎲 Chess960</button>
                </div>
              )}
            </div>

            {/* Engine Menu */}
            <div className="relative">
              <button 
                onClick={() => setMenuOpen(menuOpen === 'engine' ? null : 'engine')}
                className="px-3 py-1.5 rounded hover:bg-white/10 text-gray-300 transition-colors cursor-pointer"
              >
                Engine
              </button>
              {menuOpen === 'engine' && (
                <div className="absolute top-full left-0 mt-1 bg-gray-800 rounded-lg shadow-xl border border-gray-700 py-1 w-48 z-50">
                  <button onClick={() => { toggleAnalysis(gameState.fen); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">
                    {isAnalyzing ? '⏹ Stop Analysis' : '▶ Start Analysis'}
                  </button>
                  <button onClick={() => { setSettingsOpen(true); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">⚙️ Engine Settings</button>
                  <hr className="border-gray-700 my-1" />
                  <button onClick={() => setMenuOpen(null)} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">📊 Stockfish 16.1</button>
                </div>
              )}
            </div>

            {/* Training Menu */}
            <button 
              onClick={() => setTrainingOpen(true)}
              className="px-3 py-1.5 rounded hover:bg-white/10 text-gray-300 transition-colors cursor-pointer"
            >
              Training
            </button>

            {/* Tools Menu */}
            <div className="relative">
              <button 
                onClick={() => setMenuOpen(menuOpen === 'tools' ? null : 'tools')}
                className="px-3 py-1.5 rounded hover:bg-white/10 text-gray-300 transition-colors cursor-pointer"
              >
                Tools
              </button>
              {menuOpen === 'tools' && (
                <div className="absolute top-full left-0 mt-1 bg-gray-800 rounded-lg shadow-xl border border-gray-700 py-1 w-48 z-50">
                  <button onClick={() => { setFenOpen(true); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">📋 FEN Viewer</button>
                  <button onClick={() => { setReviewOpen(true); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">📊 Game Review</button>
                  <button onClick={() => { setExplorerOpen(true); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">📖 Opening Explorer</button>
                  <button onClick={() => setMenuOpen(null)} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">🗃️ Database</button>
                </div>
              )}
            </div>

            {/* Settings */}
            <div className="relative">
              <button 
                onClick={() => setMenuOpen(menuOpen === 'settings' ? null : 'settings')}
                className="px-3 py-1.5 rounded hover:bg-white/10 text-gray-300 transition-colors cursor-pointer"
              >
                ⚙️ Settings
              </button>
              {menuOpen === 'settings' && (
                <div className="absolute top-full right-0 mt-1 bg-gray-800 rounded-lg shadow-xl border border-gray-700 py-1 w-56 z-50">
                  <button onClick={() => { setSettingsOpen(true); setMenuOpen(null); }} className="w-full text-left px-3 py-1.5 hover:bg-gray-700 text-gray-300 text-sm cursor-pointer">⚙️ All Settings</button>
                  <hr className="border-gray-700 my-1" />
                  <div className="px-3 py-1 text-gray-500 text-xs">♟️ Piece Theme</div>
                  {PIECE_THEME_INFO.map(pt => (
                    <button
                      key={pt.id}
                      onClick={() => { setPieceTheme(pt.id); setMenuOpen(null); }}
                      className={`w-full text-left px-3 py-1.5 hover:bg-gray-700 text-sm cursor-pointer flex items-center gap-2 ${pieceTheme === pt.id ? 'text-blue-300' : 'text-gray-300'}`}
                    >
                      <span
                        className="flex items-center justify-center"
                        style={{ width: 18, height: 18 }}
                        dangerouslySetInnerHTML={{ __html: pt.preview }}
                      />
                      {pt.name}
                      {pieceTheme === pt.id && <span className="ml-auto text-blue-400">✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </nav>

          {/* Mobile menu button */}
          <button 
            onClick={() => setSettingsOpen(true)}
            className="md:hidden text-gray-300 text-xl cursor-pointer"
          >
            ⚙️
          </button>
        </div>
      </header>

      {/* ===== MAIN CONTENT ===== */}
      <main className="flex-1 flex flex-col lg:flex-row items-start justify-center gap-4 p-4 max-w-7xl mx-auto w-full">
        {/* Left: Chessboard */}
        <div className="flex gap-2">
          {/* Eval Bar */}
          <EvalBar 
            score={engineInfo.score} 
            isMate={engineInfo.isMate} 
            mateIn={engineInfo.mateIn}
            boardSize={boardSize}
          />
          
          {/* Board */}
          <div>
            {/* Chess Clock */}
            {clockEnabled && (
              <div className="mb-2" style={{ width: boardSize }}>
                <ChessClock isRunning={gameState.turn === 'w'} whiteTime={whiteTime} blackTime={blackTime} />
              </div>
            )}
            
            <ChessBoard
              gameState={gameState}
              flipped={flipped}
              selectedSquare={selectedSquare}
              setSelectedSquare={setSelectedSquare}
              getLegalMoves={getLegalMoves}
              tryMove={tryMove}
              theme={theme}
              boardSize={boardSize}
              pieceTheme={pieceTheme}
            />
            
            {/* Game Controls */}
            <div className="flex items-center justify-center gap-2 mt-3">
              <button onClick={flipBoard} className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded-lg text-sm transition-colors cursor-pointer" title="Flip Board (F)">
                🔄
              </button>
              <button onClick={undo} className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded-lg text-sm transition-colors cursor-pointer" title="Undo (Ctrl+Z)">
                ◀
              </button>
              <button onClick={redo} className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded-lg text-sm transition-colors cursor-pointer" title="Redo (Ctrl+Y)">
                ▶
              </button>
              <button onClick={newGame} className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded-lg text-sm transition-colors cursor-pointer" title="New Game (Ctrl+N)">
                🆕
              </button>
              <button 
                onClick={() => toggleAnalysis(gameState.fen)}
                className={`px-3 py-1.5 rounded-lg text-sm transition-colors cursor-pointer ${isAnalyzing ? 'bg-red-700 hover:bg-red-600' : 'bg-green-700 hover:bg-green-600'} text-white`}
                title="Toggle Analysis (Space)"
              >
                {isAnalyzing ? '⏹ Stop' : '▶ Analyze'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Panel */}
        <div className="flex-1 max-w-sm w-full space-y-3">
          {/* Opening Name */}
          <div className="bg-black/30 rounded-lg p-3">
            <div className="text-xs text-gray-400 mb-1">Opening</div>
            <div className="text-sm font-semibold text-white">
              {openingName || 'Starting Position'}
            </div>
          </div>

          {/* Status */}
          <div className={`rounded-lg p-3 text-center font-semibold ${
            gameState.isCheckmate ? 'bg-red-900/50 border border-red-700' :
            gameState.isCheck ? 'bg-yellow-900/50 border border-yellow-700' :
            gameState.isDraw ? 'bg-blue-900/50 border border-blue-700' :
            'bg-black/30'
          }`}>
            <span className="text-sm">{statusText}</span>
            {gameState.isGameOver && (
              <button 
                onClick={() => setReviewOpen(true)}
                className="ml-2 bg-white/20 hover:bg-white/30 px-2 py-0.5 rounded text-xs transition-colors cursor-pointer"
              >
                📊 Review
              </button>
            )}
          </div>

          {/* Engine Panel */}
          <EnginePanel engineInfo={engineInfo} isAnalyzing={isAnalyzing} />

          {/* Move List */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-semibold text-gray-300">Moves</h3>
              <span className="text-xs text-gray-500">{gameState.moveHistory.length} moves</span>
            </div>
            <MoveList 
              moves={gameState.moveHistory} 
              onMoveClick={goToMove}
            />
          </div>

          {/* AI Coach Explanation */}
          {engineInfo.pv.length > 0 && (
            <div className="bg-blue-900/20 border border-blue-800/50 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-lg">🎓</span>
                <span className="text-sm font-semibold text-blue-300">AI Coach</span>
              </div>
              <p className="text-xs text-blue-200 leading-relaxed">
                {engineInfo.pv[0] && `Best move: ${engineInfo.pv[0]}. `}
                {engineInfo.score > 1 && "White has a clear advantage. "}
                {engineInfo.score < -1 && "Black has a clear advantage. "}
                {Math.abs(engineInfo.score) <= 1 && "The position is roughly equal. "}
                {engineInfo.score > 2 && "Look for ways to convert your advantage into a win."}
                {engineInfo.score < -2 && "Try to defend carefully and create counterplay."}
                {Math.abs(engineInfo.score) <= 0.5 && "Focus on piece development and king safety."}
              </p>
            </div>
          )}

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-2">
            <button 
              onClick={() => setTrainingOpen(true)}
              className="bg-purple-900/50 hover:bg-purple-800/50 border border-purple-700/50 text-purple-200 p-2 rounded-lg text-sm transition-colors cursor-pointer"
            >
              🧩 Puzzles
            </button>
            <button 
              onClick={() => setExplorerOpen(true)}
              className="bg-cyan-900/50 hover:bg-cyan-800/50 border border-cyan-700/50 text-cyan-200 p-2 rounded-lg text-sm transition-colors cursor-pointer"
            >
              📖 Openings
            </button>
            <button 
              onClick={() => {
                // Cycle through piece themes
                const themes: PieceTheme[] = ['classic', 'alpha', 'modern', 'wood', 'gothic'];
                const currentIndex = themes.indexOf(pieceTheme);
                const nextIndex = (currentIndex + 1) % themes.length;
                setPieceTheme(themes[nextIndex]);
              }}
              className="bg-indigo-900/50 hover:bg-indigo-800/50 border border-indigo-700/50 text-indigo-200 p-2 rounded-lg text-sm transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              title={`Current: ${PIECE_THEME_INFO.find(p => p.id === pieceTheme)?.name}. Click to cycle.`}
            >
              <span
                className="flex items-center justify-center"
                style={{ width: 18, height: 18 }}
                dangerouslySetInnerHTML={{ __html: PIECE_THEME_INFO.find(p => p.id === pieceTheme)?.preview || '' }}
              />
              ♟️ {PIECE_THEME_INFO.find(p => p.id === pieceTheme)?.name}
            </button>
            <button 
              onClick={handleExportPgn}
              className="bg-orange-900/50 hover:bg-orange-800/50 border border-orange-700/50 text-orange-200 p-2 rounded-lg text-sm transition-colors cursor-pointer"
            >
              💾 Save PGN
            </button>
          </div>
        </div>
      </main>

      {/* ===== STATUS BAR ===== */}
      <footer className="bg-black/40 border-t border-gray-700/50 px-4 py-1.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center gap-4">
            <span>Turn: <span className="text-white">{gameState.turn === 'w' ? 'White' : 'Black'}</span></span>
            <span>Move: <span className="text-white">{Math.ceil((gameState.moveHistory.length + 1) / 2)}</span></span>
            {opening && <span className="hidden sm:inline">Opening: <span className="text-white">{opening.eco}</span></span>}
          </div>
          <div className="flex items-center gap-4">
            <span>Engine: <span className="text-green-400">Stockfish 16.1</span></span>
            <span className="hidden sm:inline">Board: <span className="text-white capitalize">{boardTheme}</span></span>
            <span className="hidden md:inline">Pieces: <span className="text-white capitalize">{PIECE_THEME_INFO.find(p => p.id === pieceTheme)?.name || 'Classic'}</span></span>
          </div>
        </div>
      </footer>

      {/* ===== MODALS ===== */}
      {promotionPending && (
        <PromotionDialog
          color={gameState.turn}
          onSelect={(piece) => completePromotion(piece as any)}
          onCancel={cancelPromotion}
          pieceTheme={pieceTheme}
        />
      )}

      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        theme={boardTheme}
        setTheme={setBoardTheme}
        pieceTheme={pieceTheme}
        setPieceTheme={setPieceTheme}
        engineSettings={engineSettings}
        setEngineSettings={setEngineSettings}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        animationsEnabled={animationsEnabled}
        setAnimationsEnabled={setAnimationsEnabled}
      />

      <TrainingModal
        isOpen={trainingOpen}
        onClose={() => setTrainingOpen(false)}
        loadFen={loadFen}
        gameState={gameState}
      />

      <FenDialog
        isOpen={fenOpen}
        onClose={() => setFenOpen(false)}
        fen={gameState.fen}
        loadFen={loadFen}
      />

      <GameReview
        isOpen={reviewOpen}
        onClose={() => setReviewOpen(false)}
        moves={gameState.moveHistory}
      />

      <OpeningExplorer
        isOpen={explorerOpen}
        onClose={() => setExplorerOpen(false)}
        loadFen={loadFen}
      />

      {/* Click outside to close menus */}
      {menuOpen && (
        <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(null)} />
      )}
    </div>
  );
}
