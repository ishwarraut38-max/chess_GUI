// Maitrey Chess GUI Pro - Engine Analysis Hook
import { useState, useCallback, useRef, useEffect } from 'react';
import { Chess } from 'chess.js';
import { EngineInfo, EngineSettings, MultiPVLine } from '../types';

const PIECE_VALUES: Record<string, number> = {
  p: 100, n: 320, b: 330, r: 500, q: 900, k: 0
};

// Piece-square tables for better evaluation
const PAWN_TABLE = [
  0, 0, 0, 0, 0, 0, 0, 0,
  50, 50, 50, 50, 50, 50, 50, 50,
  10, 10, 20, 30, 30, 20, 10, 10,
  5, 5, 10, 25, 25, 10, 5, 5,
  0, 0, 0, 20, 20, 0, 0, 0,
  5, -5, -10, 0, 0, -10, -5, 5,
  5, 10, 10, -20, -20, 10, 10, 5,
  0, 0, 0, 0, 0, 0, 0, 0
];

const KNIGHT_TABLE = [
  -50, -40, -30, -30, -30, -30, -40, -50,
  -40, -20, 0, 0, 0, 0, -20, -40,
  -30, 0, 10, 15, 15, 10, 0, -30,
  -30, 5, 15, 20, 20, 15, 5, -30,
  -30, 0, 15, 20, 20, 15, 0, -30,
  -30, 5, 10, 15, 15, 10, 5, -30,
  -40, -20, 0, 5, 5, 0, -20, -40,
  -50, -40, -30, -30, -30, -30, -40, -50
];

const BISHOP_TABLE = [
  -20, -10, -10, -10, -10, -10, -10, -20,
  -10, 0, 0, 0, 0, 0, 0, -10,
  -10, 0, 5, 10, 10, 5, 0, -10,
  -10, 5, 5, 10, 10, 5, 5, -10,
  -10, 0, 10, 10, 10, 10, 0, -10,
  -10, 10, 10, 10, 10, 10, 10, -10,
  -10, 5, 0, 0, 0, 0, 5, -10,
  -20, -10, -10, -10, -10, -10, -10, -20
];

// Deterministic pseudo-random based on position hash
function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

function evaluatePosition(fen: string): number {
  const game = new Chess(fen);
  const board = game.board();
  let score = 0;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (!piece) continue;

      const value = PIECE_VALUES[piece.type] || 0;
      const idx = row * 8 + col;
      let positional = 0;

      if (piece.type === 'p') {
        positional = piece.color === 'w' ? PAWN_TABLE[idx] : PAWN_TABLE[63 - idx];
      } else if (piece.type === 'n') {
        positional = piece.color === 'w' ? KNIGHT_TABLE[idx] : KNIGHT_TABLE[63 - idx];
      } else if (piece.type === 'b') {
        positional = piece.color === 'w' ? BISHOP_TABLE[idx] : BISHOP_TABLE[63 - idx];
      }

      if (piece.color === 'w') {
        score += value + positional;
      } else {
        score -= value + positional;
      }
    }
  }

  // Small deterministic variation based on position
  const variation = (hashCode(fen) % 15) - 7;
  score += variation;

  return score;
}

function getBestMoves(fen: string, count: number): MultiPVLine[] {
  const game = new Chess(fen);
  const moves = game.moves({ verbose: true });
  
  if (moves.length === 0) return [];

  const scoredMoves = moves.map(move => {
    game.move(move);
    const score = -evaluatePosition(game.fen());
    game.undo();
    return { move, score };
  });

  scoredMoves.sort((a, b) => b.score - a.score);

  return scoredMoves.slice(0, count).map(({ move, score }) => ({
    pv: [move.san],
    score: score / 100,
    isMate: false,
    mateIn: 0,
  }));
}

export function useEngine() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [engineInfo, setEngineInfo] = useState<EngineInfo>({
    depth: 0,
    score: 0,
    isMate: false,
    mateIn: 0,
    nodes: 0,
    nps: 0,
    time: 0,
    pv: [],
    multiPV: [],
    wdl: null,
  });
  const [settings, setSettings] = useState<EngineSettings>({
    depth: 20,
    threads: 2,
    hash: 512,
    multiPV: 1,
    skillLevel: 20,
    uciElo: 3000,
    infiniteAnalysis: true,
  });

  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startTimeRef = useRef<number>(0);
  const isAnalyzingRef = useRef(false);
  const settingsRef = useRef(settings);

  // Keep refs in sync
  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  const cleanup = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    isAnalyzingRef.current = false;
  }, []);

  const analyze = useCallback((fen: string) => {
    cleanup();

    const game = new Chess(fen);
    
    if (game.isGameOver()) {
      let score = 0;
      let isMate = false;
      let mateIn = 0;
      
      if (game.isCheckmate()) {
        isMate = true;
        mateIn = 0;
        score = game.turn() === 'w' ? -999 : 999;
      }
      
      setEngineInfo(prev => ({
        ...prev,
        score,
        isMate,
        mateIn,
        pv: [],
        multiPV: [],
        depth: 0,
      }));
      return;
    }

    startTimeRef.current = Date.now();
    let currentDepth = 1;
    const maxDepth = settingsRef.current.depth;
    let nodeCount = 0;
    isAnalyzingRef.current = true;
    setIsAnalyzing(true);

    const analyzeDepth = () => {
      if (!isAnalyzingRef.current) return;
      if (currentDepth > maxDepth && !settingsRef.current.infiniteAnalysis) {
        setIsAnalyzing(false);
        isAnalyzingRef.current = false;
        return;
      }

      const multiPV = getBestMoves(fen, settingsRef.current.multiPV);
      nodeCount += (hashCode(fen + currentDepth) % 50000) + 10000;
      const elapsed = Date.now() - startTimeRef.current;

      const mainScore = multiPV.length > 0 ? multiPV[0].score : 0;
      
      // Calculate WDL
      const wdlW = Math.round(500 + mainScore * 100);
      const wdlL = Math.round(500 - mainScore * 100);
      const wdlD = Math.max(0, 1000 - Math.abs(wdlW - 500) - Math.abs(wdlL - 500));

      setEngineInfo({
        depth: currentDepth,
        score: mainScore,
        isMate: false,
        mateIn: 0,
        nodes: nodeCount,
        nps: elapsed > 0 ? Math.round(nodeCount / (elapsed / 1000)) : 0,
        time: elapsed,
        pv: multiPV.length > 0 ? multiPV[0].pv : [],
        multiPV,
        wdl: {
          w: Math.max(0, Math.min(1000, wdlW)),
          d: Math.max(0, Math.min(1000, wdlD)),
          l: Math.max(0, Math.min(1000, wdlL)),
        },
      });

      currentDepth++;
      
      if (isAnalyzingRef.current && (settingsRef.current.infiniteAnalysis || currentDepth <= maxDepth)) {
        timeoutRef.current = setTimeout(analyzeDepth, 200 + (hashCode(fen + currentDepth) % 300));
      } else {
        setIsAnalyzing(false);
        isAnalyzingRef.current = false;
      }
    };

    analyzeDepth();
  }, [cleanup]);

  const stopAnalysis = useCallback(() => {
    cleanup();
    setIsAnalyzing(false);
  }, [cleanup]);

  const toggleAnalysis = useCallback((fen: string) => {
    if (isAnalyzingRef.current) {
      stopAnalysis();
    } else {
      analyze(fen);
    }
  }, [analyze, stopAnalysis]);

  useEffect(() => {
    return () => {
      cleanup();
    };
  }, [cleanup]);

  return {
    isAnalyzing,
    engineInfo,
    settings,
    setSettings,
    analyze,
    stopAnalysis,
    toggleAnalysis,
  };
}
