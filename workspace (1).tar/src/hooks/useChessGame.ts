// Maitrey Chess GUI Pro - Chess Game Logic Hook
import { useState, useCallback, useRef } from 'react';
import { Chess, Square, Move, PieceSymbol, Color } from 'chess.js';

export interface GameState {
  fen: string;
  pgn: string;
  isCheck: boolean;
  isCheckmate: boolean;
  isDraw: boolean;
  isStalemate: boolean;
  isGameOver: boolean;
  turn: Color;
  moveHistory: Move[];
  legalMoves: Square[];
  lastMove: { from: Square; to: Square } | null;
}

function buildGameState(game: Chess): GameState {
  const moves = game.history({ verbose: true });
  const lastMove = moves.length > 0
    ? { from: moves[moves.length - 1].from, to: moves[moves.length - 1].to }
    : null;

  return {
    fen: game.fen(),
    pgn: game.pgn(),
    isCheck: game.isCheck(),
    isCheckmate: game.isCheckmate(),
    isDraw: game.isDraw(),
    isStalemate: game.isStalemate(),
    isGameOver: game.isGameOver(),
    turn: game.turn(),
    moveHistory: moves,
    legalMoves: [],
    lastMove,
  };
}

export function useChessGame() {
  const gameRef = useRef(new Chess());
  // Store full PGN separately so goToMove can reconstruct any position
  const fullPgnRef = useRef('');
  const [gameState, setGameState] = useState<GameState>(() => buildGameState(gameRef.current));
  const [future, setFuture] = useState<Move[]>([]);
  const [flipped, setFlipped] = useState(false);
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [promotionPending, setPromotionPending] = useState<{ from: Square; to: Square } | null>(null);

  const updateState = useCallback(() => {
    const game = gameRef.current;
    // Save the full PGN whenever state changes
    fullPgnRef.current = game.pgn();
    setGameState(buildGameState(game));
  }, []);

  const makeMove = useCallback((from: Square, to: Square, promotion?: PieceSymbol): boolean => {
    const game = gameRef.current;
    try {
      const move = game.move({ from, to, promotion: promotion || undefined });
      if (move) {
        setFuture([]);
        updateState();
        return true;
      }
    } catch {
      // Invalid move - ignore
    }
    return false;
  }, [updateState]);

  const tryMove = useCallback((from: Square, to: Square): boolean => {
    const game = gameRef.current;
    const piece = game.get(from);
    if (piece && piece.type === 'p') {
      const rank = to[1];
      if ((piece.color === 'w' && rank === '8') || (piece.color === 'b' && rank === '1')) {
        setPromotionPending({ from, to });
        return false;
      }
    }
    return makeMove(from, to);
  }, [makeMove]);

  const completePromotion = useCallback((piece: PieceSymbol) => {
    if (promotionPending) {
      makeMove(promotionPending.from, promotionPending.to, piece);
      setPromotionPending(null);
    }
  }, [promotionPending, makeMove]);

  const cancelPromotion = useCallback(() => {
    setPromotionPending(null);
  }, []);

  const getLegalMoves = useCallback((square: Square): Square[] => {
    const game = gameRef.current;
    try {
      const moves = game.moves({ square, verbose: true });
      return moves.map(m => m.to);
    } catch {
      return [];
    }
  }, []);

  const undo = useCallback(() => {
    const game = gameRef.current;
    const move = game.undo();
    if (move) {
      setFuture(prev => [move, ...prev]);
      updateState();
    }
  }, [updateState]);

  const redo = useCallback(() => {
    if (future.length > 0) {
      const move = future[0];
      const game = gameRef.current;
      try {
        game.move({
          from: move.from,
          to: move.to,
          promotion: move.promotion || undefined,
        });
        setFuture(prev => prev.slice(1));
        updateState();
      } catch {
        // If redo fails, clear future
        setFuture([]);
      }
    }
  }, [future, updateState]);

  const newGame = useCallback(() => {
    gameRef.current = new Chess();
    fullPgnRef.current = '';
    setFuture([]);
    setSelectedSquare(null);
    setPromotionPending(null);
    updateState();
  }, [updateState]);

  const loadFen = useCallback((fen: string): boolean => {
    try {
      const newGame = new Chess(fen);
      gameRef.current = newGame;
      fullPgnRef.current = '';
      setFuture([]);
      setSelectedSquare(null);
      setPromotionPending(null);
      updateState();
      return true;
    } catch {
      return false;
    }
  }, [updateState]);

  const loadPgn = useCallback((pgn: string): boolean => {
    try {
      const newGame = new Chess();
      newGame.loadPgn(pgn);
      gameRef.current = newGame;
      fullPgnRef.current = newGame.pgn();
      setFuture([]);
      setSelectedSquare(null);
      setPromotionPending(null);
      updateState();
      return true;
    } catch {
      return false;
    }
  }, [updateState]);

  const flipBoard = useCallback(() => {
    setFlipped(prev => !prev);
  }, []);

  const goToMove = useCallback((moveIndex: number) => {
    // Use the stored full PGN to reconstruct the game up to moveIndex
    const savedPgn = fullPgnRef.current;
    if (!savedPgn && moveIndex < 0) {
      // No moves to go to
      gameRef.current = new Chess();
      setFuture([]);
      updateState();
      return;
    }

    try {
      // Create a temporary game to get all moves
      const tempGame = new Chess();
      if (savedPgn) {
        tempGame.loadPgn(savedPgn);
      }
      const allMoves = tempGame.history({ verbose: true });

      // Rebuild the game up to the target move
      const newGame = new Chess();
      for (let i = 0; i <= moveIndex && i < allMoves.length; i++) {
        newGame.move({
          from: allMoves[i].from,
          to: allMoves[i].to,
          promotion: allMoves[i].promotion || undefined,
        });
      }

      gameRef.current = newGame;
      // Store remaining moves as future for redo
      const remaining = allMoves.slice(moveIndex + 1);
      setFuture(remaining);
      updateState();
    } catch {
      // If reconstruction fails, reset
      gameRef.current = new Chess();
      setFuture([]);
      updateState();
    }
  }, [updateState]);

  return {
    gameState,
    selectedSquare,
    setSelectedSquare,
    promotionPending,
    flipped,
    makeMove,
    tryMove,
    completePromotion,
    cancelPromotion,
    getLegalMoves,
    undo,
    redo,
    newGame,
    loadFen,
    loadPgn,
    flipBoard,
    goToMove,
  };
}
