// Maitrey Chess GUI Pro - Theme Configuration
import { ThemeColors, BoardTheme } from '../types';

export const THEMES: Record<BoardTheme, ThemeColors> = {
  wood: {
    lightSquare: '#F3EBDD',
    darkSquare: '#B58863',
    background: '#302E2C',
    panelBg: '#1E1E1E',
    text: '#E8E8E8',
    accent: '#E8B94E',
    highlight: '#829769',
    lastMove: '#CED26B80',
    check: '#FF000080',
  },
  green: {
    lightSquare: '#FFFFDD',
    darkSquare: '#6D8A45',
    background: '#2C3E2C',
    panelBg: '#1E2E1E',
    text: '#E8E8E8',
    accent: '#7CB342',
    highlight: '#829769',
    lastMove: '#CED26B80',
    check: '#FF000080',
  },
  blue: {
    lightSquare: '#DEE3E6',
    darkSquare: '#788A9E',
    background: '#1C2833',
    panelBg: '#1A2332',
    text: '#E8E8E8',
    accent: '#4FC3F7',
    highlight: '#829769',
    lastMove: '#CED26B80',
    check: '#FF000080',
  },
  marble: {
    lightSquare: '#F0F0F0',
    darkSquare: '#8B8680',
    background: '#2D2D2D',
    panelBg: '#1E1E1E',
    text: '#E8E8E8',
    accent: '#BDBDBD',
    highlight: '#829769',
    lastMove: '#CED26B80',
    check: '#FF000080',
  },
  tournament: {
    lightSquare: '#F0D9B5',
    darkSquare: '#B58863',
    background: '#262421',
    panelBg: '#1A1818',
    text: '#E8E8E8',
    accent: '#FFD54F',
    highlight: '#829769',
    lastMove: '#CED26B80',
    check: '#FF000080',
  },
  dark: {
    lightSquare: '#769656',
    darkSquare: '#546E3A',
    background: '#1A1A2E',
    panelBg: '#16213E',
    text: '#E8E8E8',
    accent: '#E94560',
    highlight: '#BACA44',
    lastMove: '#BACA4480',
    check: '#FF000080',
  },
  light: {
    lightSquare: '#FFFFFF',
    darkSquare: '#769656',
    background: '#F5F5F5',
    panelBg: '#FFFFFF',
    text: '#1A1A1A',
    accent: '#2196F3',
    highlight: '#829769',
    lastMove: '#CED26B80',
    check: '#FF000080',
  },
};

export function getTheme(name: BoardTheme): ThemeColors {
  return THEMES[name] || THEMES.wood;
}

// Chess piece unicode characters
export const PIECE_UNICODE: Record<string, string> = {
  'wK': '♔', 'wQ': '♕', 'wR': '♖', 'wB': '♗', 'wN': '♘', 'wP': '♙',
  'bK': '♚', 'bQ': '♛', 'bR': '♜', 'bB': '♝', 'bN': '♞', 'bP': '♟',
};
