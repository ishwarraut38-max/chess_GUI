// Maitrey Chess GUI Pro - Opening Database
import { OpeningEntry } from '../types';

export const OPENINGS: OpeningEntry[] = [
  // Open Games (1.e4 e5)
  { eco: "C00", name: "King's Pawn Opening", moves: "1. e4", fen: "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "C20", name: "King's Pawn Game", moves: "1. e4 e5", fen: "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "C20", name: "King's Pawn Game: Alapin Opening", moves: "1. e4 e5 2. Ne2", fen: "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPPNPPP/RNBQKB1R" },
  { eco: "C21", name: "Center Game", moves: "1. e4 e5 2. d4", fen: "rnbqkbnr/pppp1ppp/8/4p3/3PP3/8/PPP2PPP/RNBQKBNR" },
  { eco: "C23", name: "Bishop's Opening", moves: "1. e4 e5 2. Bc4", fen: "rnbqkbnr/pppp1ppp/8/4p3/2B1P3/8/PPPP1PPP/RNBQK1NR" },
  { eco: "C25", name: "Vienna Game", moves: "1. e4 e5 2. Nc3", fen: "rnbqkbnr/pppp1ppp/8/4p3/4P3/2N5/PPPP1PPP/R1BQKBNR" },
  { eco: "C30", name: "King's Gambit", moves: "1. e4 e5 2. f4", fen: "rnbqkbnr/pppp1ppp/8/4p3/4PP2/8/PPPP2PP/RNBQKBNR" },
  { eco: "C42", name: "Petrov's Defense", moves: "1. e4 e5 2. Nf3 Nf6", fen: "rnbqkb1r/pppp1ppp/5n2/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R" },
  { eco: "C44", name: "Scotch Game", moves: "1. e4 e5 2. Nf3 Nc6 3. d4", fen: "r1bqkbnr/pppp1ppp/2n5/4p3/3PP3/5N2/PPP2PPP/RNBQKB1R" },
  { eco: "C45", name: "Scotch Game", moves: "1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4", fen: "r1bqkbnr/pppp1ppp/2n5/8/3NP3/8/PPP2PPP/RNBQKB1R" },
  { eco: "C46", name: "Four Knights Game", moves: "1. e4 e5 2. Nf3 Nc6 3. Nc3 Nf6", fen: "r1bqkb1r/pppp1ppp/2n2n2/4p3/4P3/2N2N2/PPPP1PPP/R1BQKB1R" },
  { eco: "C50", name: "Italian Game", moves: "1. e4 e5 2. Nf3 Nc6 3. Bc4", fen: "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R" },
  { eco: "C51", name: "Evans Gambit", moves: "1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4", fen: "r1bqk1nr/pppp1ppp/2n5/2b1p3/1PB1P3/5N2/P1PP1PPP/RNBQK2R" },
  { eco: "C54", name: "Italian Game: Giuoco Piano", moves: "1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5", fen: "r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R" },
  { eco: "C55", name: "Two Knights Defense", moves: "1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6", fen: "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R" },
  { eco: "C60", name: "Ruy Lopez", moves: "1. e4 e5 2. Nf3 Nc6 3. Bb5", fen: "r1bqkbnr/pppp1ppp/2n5/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R" },
  { eco: "C65", name: "Ruy Lopez: Berlin Defense", moves: "1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6", fen: "r1bqkb1r/pppp1ppp/2n2n2/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R" },
  { eco: "C68", name: "Ruy Lopez: Exchange Variation", moves: "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Bxc6", fen: "r1bqkbnr/1ppp1ppp/p1B5/4p3/4P3/5N2/PPPP1PPP/RNBQK2R" },
  { eco: "C70", name: "Ruy Lopez: Morphy Defense", moves: "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6", fen: "r1bqkbnr/1ppp1ppp/p1n5/4p3/1B2P3/5N2/PPPP1PPP/RNBQK2R" },
  { eco: "C78", name: "Ruy Lopez: Archangelsk Variation", moves: "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O b5", fen: "r1bqkb1r/2pp1ppp/p1n2n2/1p2p3/4P3/1B3N2/PPPP1PPP/RNBQ1RK1" },
  { eco: "C80", name: "Ruy Lopez: Open Variation", moves: "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Nxe4", fen: "r1bqkb1r/1ppp1ppp/p1n5/4p3/2B1n3/5N2/PPPP1PPP/RNBQ1RK1" },

  // Semi-Open Games
  { eco: "B00", name: "King's Pawn Game", moves: "1. e4", fen: "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "B02", name: "Alekhine's Defense", moves: "1. e4 Nf6", fen: "rnbqkb1r/pppppppp/5n2/8/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "B10", name: "Caro-Kann Defense", moves: "1. e4 c6", fen: "rnbqkbnr/pp1ppppp/2p5/8/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "B12", name: "Caro-Kann: Advance Variation", moves: "1. e4 c6 2. d4 d5 3. e5", fen: "rnbqkbnr/pp2pppp/2p5/3pP3/3P4/8/PPP2PPP/RNBQKBNR" },
  { eco: "B15", name: "Caro-Kann Defense", moves: "1. e4 c6 2. d4 d5 3. Nc3", fen: "rnbqkbnr/pp2pppp/2p5/3p4/3PP3/2N5/PPP2PPP/R1BQKBNR" },
  { eco: "B17", name: "Caro-Kann: Steinitz Variation", moves: "1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nd7", fen: "r1bqkbnr/pp1npppp/2p5/8/3NN3/8/PPP2PPP/R1BQKB1R" },
  { eco: "B20", name: "Sicilian Defense", moves: "1. e4 c5", fen: "rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "B21", name: "Sicilian: Smith-Morra Gambit", moves: "1. e4 c5 2. d4", fen: "rnbqkbnr/pp1ppppp/8/2p5/3PP3/8/PPP2PPP/RNBQKBNR" },
  { eco: "B22", name: "Sicilian: Alapin Variation", moves: "1. e4 c5 2. c3", fen: "rnbqkbnr/pp1ppppp/8/2p5/4P3/2P5/PP1P1PPP/RNBQKBNR" },
  { eco: "B23", name: "Sicilian: Closed Variation", moves: "1. e4 c5 2. Nc3", fen: "rnbqkbnr/pp1ppppp/8/2p5/4P3/2N5/PPPP1PPP/R1BQKBNR" },
  { eco: "B27", name: "Sicilian Defense", moves: "1. e4 c5 2. Nf3", fen: "rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R" },
  { eco: "B30", name: "Sicilian: Old Variation", moves: "1. e4 c5 2. Nf3 Nc6", fen: "r1bqkbnr/pp1ppppp/2n5/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R" },
  { eco: "B32", name: "Sicilian: Open Variation", moves: "1. e4 c5 2. Nf3 Nc6 3. d4", fen: "r1bqkbnr/pp1ppppp/2n5/2p5/3PP3/5N2/PPP2PPP/RNBQKB1R" },
  { eco: "B40", name: "Sicilian: French Variation", moves: "1. e4 c5 2. Nf3 e6", fen: "rnbqkbnr/pp1p1ppp/4p3/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R" },
  { eco: "B50", name: "Sicilian Defense", moves: "1. e4 c5 2. Nf3 d6", fen: "rnbqkbnr/pp2pppp/3p4/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R" },
  { eco: "B57", name: "Sicilian: Classical Variation", moves: "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 Nc6", fen: "r1bqkb1r/pp2pppp/2np1n2/8/3NP3/2N5/PPP2PPP/R1BQKB1R" },
  { eco: "B60", name: "Sicilian: Richter-Rauzer", moves: "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 Nc6 6. Bg5", fen: "r1bqkb1r/pp2pppp/2np1n2/6B1/3NP3/2N5/PPP2PPP/R2QKB1R" },
  { eco: "B80", name: "Sicilian: Scheveningen", moves: "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e6", fen: "rnbqkb1r/pp3ppp/3ppn2/8/3NP3/2N5/PPP2PPP/R1BQKB1R" },
  { eco: "B90", name: "Sicilian: Najdorf Variation", moves: "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6", fen: "rnbqkb1r/1p2pppp/p2p1n2/8/3NP3/2N5/PPP2PPP/R1BQKB1R" },
  { eco: "B96", name: "Sicilian: Najdorf, 6.Bg5", moves: "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Bg5", fen: "rnbqkb1r/1p2pppp/p2p1n2/6B1/3NP3/2N5/PPP2PPP/R2QKB1R" },
  { eco: "B06", name: "Modern Defense", moves: "1. e4 g6", fen: "rnbqkbnr/pppppp1p/6p1/8/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "B07", name: "Pirc Defense", moves: "1. e4 d6 2. d4 Nf6 3. Nc3", fen: "rnbqkb1r/ppp1pppp/3p1n2/8/3PP3/2N5/PPP2PPP/R1BQKBNR" },
  { eco: "A00", name: "Owen's Defense", moves: "1. e4 b6", fen: "rnbqkbnr/p1pppppp/1p6/8/4P3/8/PPPP1PPP/RNBQKBNR" },
  { eco: "A40", name: "Englund Gambit", moves: "1. d4 e5", fen: "rnbqkbnr/pppp1ppp/8/4p3/3P4/8/PPP1PPPP/RNBQKBNR" },

  // Closed Games (1.d4)
  { eco: "D00", name: "Queen's Pawn Game", moves: "1. d4", fen: "rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR" },
  { eco: "D06", name: "Queen's Gambit", moves: "1. d4 d5 2. c4", fen: "rnbqkbnr/ppp1pppp/8/3p4/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "D07", name: "Queen's Gambit: Chigorin Defense", moves: "1. d4 d5 2. c4 Nc6", fen: "r1bqkbnr/ppp1pppp/2n5/3p4/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "D08", name: "Queen's Gambit: Albin Counter-Gambit", moves: "1. d4 d5 2. c4 e5", fen: "rnbqkbnr/ppp2ppp/8/3pp3/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "D10", name: "Queen's Gambit: Slav Defense", moves: "1. d4 d5 2. c4 c6", fen: "rnbqkbnr/pp2pppp/2p5/3p4/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "D20", name: "Queen's Gambit Accepted", moves: "1. d4 d5 2. c4 dxc4", fen: "rnbqkbnr/ppp1pppp/8/8/2pP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "D30", name: "Queen's Gambit Declined", moves: "1. d4 d5 2. c4 e6", fen: "rnbqkbnr/ppp2ppp/4p3/3p4/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "D35", name: "Queen's Gambit Declined: Exchange", moves: "1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. cxd5", fen: "rnbqkb1r/ppp2ppp/4pn2/3P4/3P4/2N5/PP2PPPP/R1BQKBNR" },
  { eco: "D37", name: "QGD: 4.Nf3", moves: "1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Nf3", fen: "rnbqkb1r/ppp2ppp/4pn2/3p4/2PP4/2N2N2/PP2PPPP/R1BQKB1R" },
  { eco: "D40", name: "Queen's Gambit: Semi-Tarrasch", moves: "1. d4 d5 2. c4 e6 3. Nc3 c5", fen: "rnbqkbnr/pp3ppp/4p3/2pp4/2PP4/2N5/PP2PPPP/R1BQKBNR" },
  { eco: "D43", name: "Queen's Gambit: Semi-Slav", moves: "1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 e6", fen: "rnbqkb1r/pp3ppp/2p1pn2/3p4/2PP4/2N2N2/PP2PPPP/R1BQKB1R" },
  { eco: "D52", name: "QGD: Cambridge Springs", moves: "1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Bg5 Nbd7 5. Nf3 c6 6. e3 Qa5", fen: "r1b1kb1r/pp1n1ppp/2p1pn2/q2p2B1/2PP4/2N1PN2/PP3PPP/R2QKB1R" },
  { eco: "D70", name: "Grunfeld: Exchange Variation", moves: "1. d4 Nf6 2. c4 g6 3. f3 d5 4. cxd5 Nxd5 5. e4", fen: "rnbqkb1r/ppp1pp1p/6p1/3n4/3PP3/5P2/PP4PP/RNBQKBNR" },
  { eco: "D80", name: "Grunfeld Defense", moves: "1. d4 Nf6 2. c4 g6 3. Nc3 d5", fen: "rnbqkb1r/ppp1pp1p/6p1/3p4/2PP4/2N5/PP2PPPP/R1BQKBNR" },
  { eco: "E00", name: "Indian Game", moves: "1. d4 Nf6 2. c4 e6", fen: "rnbqkb1r/pppp1ppp/4pn2/8/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "E12", name: "Queen's Indian Defense", moves: "1. d4 Nf6 2. c4 e6 3. Nf3 b6", fen: "rnbqkb1r/p1pp1ppp/1p2pn2/8/2PP4/5N2/PP2PPPP/RNBQKB1R" },
  { eco: "E20", name: "Nimzo-Indian Defense", moves: "1. d4 Nf6 2. c4 e6 3. Nc3 Bb4", fen: "rnbqk2r/pppp1ppp/4pn2/8/1bPP4/2N5/PP2PPPP/R1BQKBNR" },
  { eco: "E32", name: "Nimzo-Indian: Classical Variation", moves: "1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2", fen: "rnbqk2r/pppp1ppp/4pn2/8/1bPP4/2N5/PPQ1PPPP/R1B1KBNR" },
  { eco: "E60", name: "King's Indian Defense", moves: "1. d4 Nf6 2. c4 g6", fen: "rnbqkb1r/pppppp1p/6p1/8/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "E61", name: "King's Indian: Fianchetto", moves: "1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. Nc3 d6 5. g3", fen: "rnbqk2r/ppp1ppbp/3p1np1/8/2PP4/2N2NP1/PP2PP1P/R1BQKB1R" },
  { eco: "E70", name: "King's Indian: Classical", moves: "1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4", fen: "rnbqk2r/ppppppbp/6p1/8/2PPP3/2N5/PP3PPP/R1BQKBNR" },
  { eco: "E90", name: "King's Indian: 5.Nf3", moves: "1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3", fen: "rnbqk2r/ppp1ppbp/3p1np1/8/2PPP3/2N2N2/PP3PPP/R1BQKB1R" },

  // Flank Openings
  { eco: "A00", name: "Polish Opening", moves: "1. b4", fen: "rnbqkbnr/pppppppp/8/8/1P6/8/P1PPPPPP/RNBQKBNR" },
  { eco: "A00", name: "Grob's Attack", moves: "1. g4", fen: "rnbqkbnr/pppppppp/8/8/6P1/8/PPPPPP1P/RNBQKBNR" },
  { eco: "A01", name: "Larsen's Opening", moves: "1. b3", fen: "rnbqkbnr/pppppppp/8/8/8/1P6/P1PPPPPP/RNBQKBNR" },
  { eco: "A04", name: "Reti Opening", moves: "1. Nf3", fen: "rnbqkbnr/pppppppp/8/8/8/5N2/PPPPPPPP/RNBQKB1R" },
  { eco: "A10", name: "English Opening", moves: "1. c4", fen: "rnbqkbnr/pppppppp/8/8/2P5/8/PP1PPPPP/RNBQKBNR" },
  { eco: "A15", name: "English: Anglo-Indian", moves: "1. c4 Nf6", fen: "rnbqkb1r/pppppppp/5n2/8/2P5/8/PP1PPPPP/RNBQKBNR" },
  { eco: "A25", name: "English: Reversed Sicilian", moves: "1. c4 e5 2. Nc3 Nc6", fen: "r1bqkbnr/pppp1ppp/2n5/4p3/2P5/2N5/PP1PPPPP/R1BQKBNR" },
  { eco: "A30", name: "English: Symmetrical", moves: "1. c4 c5", fen: "rnbqkbnr/pp1ppppp/8/2p5/2P5/8/PP1PPPPP/RNBQKBNR" },
  { eco: "A45", name: "Trompowsky Attack", moves: "1. d4 Nf6 2. Bg5", fen: "rnbqkb1r/pppppppp/5n2/6B1/3P4/8/PPP1PPPP/RN1QKBNR" },
  { eco: "A46", name: "Torre Attack", moves: "1. d4 Nf6 2. Nf3 e6 3. Bg5", fen: "rnbqkb1r/pppp1ppp/4pn2/6B1/3P4/5N2/PPP1PPPP/RN1QKB1R" },
  { eco: "A50", name: "Budapest Gambit", moves: "1. d4 Nf6 2. c4 e5", fen: "rnbqkb1r/pppp1ppp/5n2/4p3/2PP4/8/PP2PPPP/RNBQKBNR" },
  { eco: "A52", name: "Budapest Gambit Accepted", moves: "1. d4 Nf6 2. c4 e5 3. dxe5 Ng4", fen: "rnbqkb1r/pppp1ppp/8/4P3/2p3n1/8/PP2PPPP/RNBQKBNR" },
  { eco: "A55", name: "Old Indian Defense", moves: "1. d4 Nf6 2. c4 d6 3. Nc3 Nbd7 4. e4 e5", fen: "r1bqkb1r/pppnnppp/3p1n2/4p3/2PPP3/2N5/PP3PPP/R1BQKBNR" },
  { eco: "A80", name: "Dutch Defense", moves: "1. d4 f5", fen: "rnbqkbnr/ppppp1pp/8/5p2/3P4/8/PPP1PPPP/RNBQKBNR" },
  { eco: "D02", name: "London System", moves: "1. d4 d5 2. Nf3 Nf6 3. Bf4", fen: "rnbqkb1r/ppp1pppp/5n2/3p4/3P1B2/5N2/PPP1PPPP/RN1QKB1R" },
];

export function findOpening(moves: string): OpeningEntry | null {
  // Try to match the current position to a known opening
  for (const opening of OPENINGS) {
    if (opening.moves === moves) {
      return opening;
    }
  }
  return null;
}

export function findOpeningByFen(fen: string): OpeningEntry | null {
  // Normalize to just the board position (first field) for comparison
  const normalizedFen = fen.split(' ')[0];
  for (const opening of OPENINGS) {
    const openingBoard = opening.fen.split(' ')[0];
    if (normalizedFen === openingBoard) {
      return opening;
    }
  }
  return null;
}

export function getOpeningName(moves: string): string {
  const opening = findOpening(moves);
  return opening ? opening.name : 'Unknown Opening';
}
