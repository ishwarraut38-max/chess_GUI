// Maitrey Chess GUI Pro - Puzzle Database
import { PuzzleData } from '../types';

export const PUZZLES: PuzzleData[] = [
  // Mate in 1 puzzles
  {
    fen: "6k1/5ppp/8/8/8/8/1q6/K7 w - - 0 1",
    moves: ["Qa8"],
    rating: 800,
    category: "Mate in 1",
    hint: "Look for back rank weakness",
  },
  {
    fen: "r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4",
    moves: ["Qxf7"],
    rating: 900,
    category: "Mate in 1",
    hint: "The f7 square is weak - only defended by the king",
  },
  {
    fen: "rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 2",
    moves: ["Qh4"],
    rating: 700,
    category: "Mate in 1",
    hint: "The king has weakened its position",
  },
  // Tactics puzzles
  {
    fen: "r1bqk2r/pppp1ppp/2n2n2/2b1p1B1/2B1P3/2N2N2/PPP2PPP/R2QK2R w KQkq - 6 6",
    moves: ["Nxe5"],
    rating: 1000,
    category: "Fork",
    hint: "Remove the defender with a knight fork",
  },
  {
    fen: "r2qkb1r/ppp2ppp/2np1n2/4p1B1/2B1P1b1/3P1N2/PPP2PPP/RN1QK2R w KQkq - 0 6",
    moves: ["Nxe5"],
    rating: 1100,
    category: "Fork",
    hint: "Knight fork on e5 wins material",
  },
  {
    fen: "r1bq1rk1/pppp1ppp/2n2n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQ1RK1 w - - 8 7",
    moves: ["Nxe5"],
    rating: 1000,
    category: "Tactics",
    hint: "The pawn on e5 is unprotected",
  },
  // Opening puzzles
  {
    fen: "rnbqkbnr/ppp2ppp/8/3pp3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 3",
    moves: ["exd5"],
    rating: 600,
    category: "Opening",
    hint: "Capture the central pawn",
  },
  {
    fen: "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3",
    moves: ["Bb5"],
    rating: 700,
    category: "Opening",
    hint: "Develop with a threat - the Ruy Lopez",
  },
  // Pin puzzles
  {
    fen: "r2qr1k1/ppp2ppp/3b4/3p4/3P4/3B4/PPP2PPP/R3R1K1 w - - 0 1",
    moves: ["Re8"],
    rating: 1200,
    category: "Pin",
    hint: "Pin the queen to the king on the back rank",
  },
  // Discovery puzzles
  {
    fen: "r1bq1rk1/ppppbppp/2n2n2/4N3/2B1P3/2N5/PPP2PPP/R1BQK2R w KQ - 0 8",
    moves: ["Nxd7"],
    rating: 1100,
    category: "Discovery",
    hint: "Discovered attack by moving the knight",
  },
  // Endgame puzzles
  {
    fen: "8/8/8/3k4/3p4/3K4/3P4/8 w - - 0 1",
    moves: ["Kc3"],
    rating: 1000,
    category: "Endgame",
    hint: "Take the opposition to stop the pawn",
  },
  {
    fen: "8/8/8/4k3/4P3/4K3/8/8 w - - 0 1",
    moves: ["Kd3"],
    rating: 900,
    category: "Endgame",
    hint: "Take the opposition with your king",
  },
  // Development puzzles
  {
    fen: "r1bqk2r/ppppbppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQ1RK1 w kq - 6 5",
    moves: ["Re1"],
    rating: 900,
    category: "Development",
    hint: "Put the rook on the open e-file",
  },
  {
    fen: "r1bq1rk1/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP1NPPP/R1BQK2R w KQ - 0 8",
    moves: ["O-O"],
    rating: 700,
    category: "Development",
    hint: "Castle to safety - but wait, the knight is on e2",
  },
  // Double attack puzzles
  {
    fen: "r2q1rk1/ppp1bppp/2n1bn2/3p4/3P4/2NBPN2/PPP2PPP/R1BQ1RK1 w - - 0 9",
    moves: ["Ne5"],
    rating: 1300,
    category: "Double Attack",
    hint: "Centralize the knight to attack two targets",
  },
  // More mate puzzles
  {
    fen: "r1bqk2r/pppp1Qpp/2n2n2/2b1p3/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 0 1",
    moves: ["Kf8"],
    rating: 500,
    category: "Defense",
    hint: "The only legal move to escape check",
  },
  // Skewer puzzle
  {
    fen: "4k3/8/8/8/8/8/4q3/4K2R w - - 0 1",
    moves: ["Rh8"],
    rating: 1100,
    category: "Skewer",
    hint: "Attack along the 8th rank",
  },
];

export function getPuzzleByCategory(category: string): PuzzleData[] {
  return PUZZLES.filter(p => p.category.toLowerCase().includes(category.toLowerCase()));
}

export function getRandomPuzzle(): PuzzleData {
  return PUZZLES[Math.floor(Math.random() * PUZZLES.length)];
}

export function getPuzzleByRating(minRating: number, maxRating: number): PuzzleData {
  const filtered = PUZZLES.filter(p => p.rating >= minRating && p.rating <= maxRating);
  if (filtered.length === 0) return getRandomPuzzle();
  return filtered[Math.floor(Math.random() * filtered.length)];
}
