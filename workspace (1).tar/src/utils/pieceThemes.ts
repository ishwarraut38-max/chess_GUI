// Maitrey Chess GUI Pro - Piece Theme Definitions
// Each theme provides SVG renderings for all 12 chess pieces (6 white, 6 black)
// SVGs are designed to render crisply at any board size

export type PieceTheme = 'classic' | 'alpha' | 'modern' | 'wood' | 'gothic';

export interface PieceThemeInfo {
  id: PieceTheme;
  name: string;
  description: string;
  preview: string; // SVG for preview in settings
}

// ===== CLASSIC THEME =====
// Clean, recognizable chess pieces inspired by standard tournament sets
const classicPieces: Record<string, string> = {
  wK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22.5 11.63V6M20 8h5" stroke-linejoin="miter"/>
      <path d="M22.5 25s4.5-7.5 3-10.5c0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5" fill="#fff" stroke-linecap="butt" stroke-linejoin="miter"/>
      <path d="M11.5 37c5.5 3.5 15.5 3.5 21 0v-7s9-4.5 6-10.5c-4-6.5-13.5-3.5-16 4V27v-3.5c-3.5-7.5-13-10.5-16-4-3 6 5 10 5 10V37z" fill="#fff"/>
      <path d="M11.5 30c5.5-3 15.5-3 21 0M11.5 33.5c5.5-3 15.5-3 21 0M11.5 37c5.5-3 15.5-3 21 0"/>
    </g>
  </svg>`,
  wQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="#fff" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M8 12a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM24.5 7.5a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM41 12a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM16 8.5a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM33 9a2 2 0 1 1-4 0 2 2 0 1 1 4 0z"/>
      <path d="M9 26c8.5-1.5 21-1.5 27 0l2-12-7 11V11l-5.5 13.5-3-15-3 15-5.5-14V25L7 14l2 12z" stroke-linecap="butt"/>
      <path d="M9 26c0 2 1.5 2 2.5 4 1 1.5 1 1 .5 3.5-1.5 1-1.5 2.5-1.5 2.5-1.5 1.5.5 2.5.5 2.5 6.5 1 16.5 1 23 0 0 0 1.5-1 0-2.5 0 0 .5-1.5-1-2.5-.5-2.5-.5-2 .5-3.5 1-2 2.5-2 2.5-4-8.5-1.5-18.5-1.5-27 0z" stroke-linecap="butt"/>
      <path d="M11.5 30c3.5-1 18.5-1 22 0M12 33.5c6-1 15-1 21 0" fill="none"/>
    </g>
  </svg>`,
  wR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="#fff" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M9 39h27v-3H9v3zM12 36v-4h21v4H12zM11 14V9h4v2h5V9h5v2h5V9h4v5" stroke-linecap="butt"/>
      <path d="M34 14l-3 3H14l-3-3"/>
      <path d="M31 17v12.5H14V17" stroke-linecap="butt" stroke-linejoin="miter"/>
      <path d="M31 29.5l1.5 2.5h-20l1.5-2.5"/>
    </g>
  </svg>`,
  wB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <g fill="#fff" stroke-linecap="butt">
        <path d="M9 36c3.39-.97 10.11.43 13.5-2 3.39 2.43 10.11 1.03 13.5 2 0 0 1.65.54 3 2-.68.97-1.65.99-3 .5-3.39-.97-10.11.46-13.5-1-3.39 1.46-10.11.03-13.5 1-1.354.49-2.323.47-3-.5 1.354-1.94 3-2 3-2z"/>
        <path d="M15 32c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2 0-2.5-2.5-4-2.5-4 5.5-1.5 6-11.5-5-15.5-11 4-10.5 14-5 15.5 0 0-2.5 1.5-2.5 4 0 0-.5.5 0 2z"/>
        <path d="M25 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 1 1 5 0z"/>
      </g>
      <path d="M17.5 26h10M15 30h15m-7.5-14.5v5M20 18h5" stroke-linejoin="miter"/>
    </g>
  </svg>`,
  wN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22 10c10.5 1 16.5 8 16 29H15c0-9 10-6.5 8-21" fill="#fff"/>
      <path d="M24 18c.38 2.91-5.55 7.37-8 9-3 2-2.82 4.34-5 4-1.042-.94 1.41-3.04 0-3-1 0 .19 1.23-1 2-1 0-4.003 1-4-4 0-2 6-12 6-12s1.89-1.9 2-3.5c-.73-.994-.5-2-.5-3 1-1 3 2.5 3 2.5h2s.78-1.992 2.5-3c1 0 1 3 1 3" fill="#fff"/>
      <path d="M9.5 25.5a.5.5 0 1 1-1 0 .5.5 0 1 1 1 0z" fill="#000"/>
      <path d="M14.933 15.75a.5 1.5 30 1 1-.866-.5.5 1.5 30 1 1 .866.5z" fill="#000" stroke-width="0"/>
    </g>
  </svg>`,
  wP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.5 9c-2.21 0-4 1.79-4 4 0 .89.29 1.71.78 2.38C17.33 16.5 16 18.59 16 21c0 2.03.94 3.84 2.41 5.03C15.41 27.09 11 31.58 11 39.5H34c0-7.92-4.41-12.41-7.41-13.47C28.06 24.84 29 23.03 29 21c0-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38 0-2.21-1.79-4-4-4z" fill="#fff" stroke="#000" stroke-width="1.5" stroke-linecap="round"/>
  </svg>`,
  bK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22.5 11.63V6" stroke-linejoin="miter"/>
      <path d="M22.5 25s4.5-7.5 3-10.5c0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5" fill="#000" stroke-linecap="butt" stroke-linejoin="miter"/>
      <path d="M11.5 37c5.5 3.5 15.5 3.5 21 0v-7s9-4.5 6-10.5c-4-6.5-13.5-3.5-16 4V27v-3.5c-3.5-7.5-13-10.5-16-4-3 6 5 10 5 10V37z" fill="#000"/>
      <path d="M20 8h5" stroke-linejoin="miter"/>
      <path d="M32 29.5s8.5-4 6.03-9.65C34.15 14 25 18 22.5 24.5l.01 2.1-.01-2.1C20 18 9.906 14 6.997 19.85c-2.497 5.65 4.853 9 4.853 9" stroke="#fff"/>
      <path d="M11.5 30c5.5-3 15.5-3 21 0m-21 3.5c5.5-3 15.5-3 21 0m-21 3.5c5.5-3 15.5-3 21 0" stroke="#fff"/>
    </g>
  </svg>`,
  bQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <g fill="#000" stroke="none">
        <circle cx="6" cy="12" r="2.75"/>
        <circle cx="14" cy="9" r="2.75"/>
        <circle cx="22.5" cy="8" r="2.75"/>
        <circle cx="31" cy="9" r="2.75"/>
        <circle cx="39" cy="12" r="2.75"/>
      </g>
      <path d="M9 26c8.5-1.5 21-1.5 27 0l2.5-12.5L31 25l-.3-14.15-5.2 11.65-3-14.75-3 14.75-5.2-11.65L14 25 6.5 13.5 9 26z" fill="#000" stroke-linecap="butt"/>
      <path d="M9 26c0 2 1.5 2 2.5 4 1 1.5 1 1 .5 3.5-1.5 1-1.5 2.5-1.5 2.5-1.5 1.5.5 2.5.5 2.5 6.5 1 16.5 1 23 0 0 0 1.5-1 0-2.5 0 0 .5-1.5-1-2.5-.5-2.5-.5-2 .5-3.5 1-2 2.5-2 2.5-4-8.5-1.5-18.5-1.5-27 0z" fill="#000" stroke-linecap="butt"/>
      <path d="M11 38.5a35 35 1 0 0 23 0" fill="none" stroke-linecap="butt"/>
      <path d="M11 29a35 35 1 0 1 23 0M12.5 31.5h20M11.5 34.5a35 35 1 0 0 22 0M10.5 37.5a35 35 1 0 0 24 0" fill="none" stroke="#fff"/>
    </g>
  </svg>`,
  bR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M9 39h27v-3H9v3zM12.5 32l1.5-2.5h17l1.5 2.5h-20zM12 36v-4h21v4H12z" fill="#000" stroke-linecap="butt"/>
      <path d="M14 29.5v-13h17v13H14z" fill="#000" stroke-linecap="butt" stroke-linejoin="miter"/>
      <path d="M14 16.5L11 14h23l-3 2.5H14zM11 14V9h4v2h5V9h5v2h5V9h4v5H11z" fill="#000" stroke-linecap="butt"/>
      <path d="M12 35.5h21M13 31.5h19M14 29.5h17M14 16.5h17M11 14h23" fill="none" stroke="#fff" stroke-width="1" stroke-linejoin="miter"/>
    </g>
  </svg>`,
  bB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <g fill="#000" stroke-linecap="butt">
        <path d="M9 36c3.39-.97 10.11.43 13.5-2 3.39 2.43 10.11 1.03 13.5 2 0 0 1.65.54 3 2-.68.97-1.65.99-3 .5-3.39-.97-10.11.46-13.5-1-3.39 1.46-10.11.03-13.5 1-1.354.49-2.323.47-3-.5 1.354-1.94 3-2 3-2z"/>
        <path d="M15 32c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2 0-2.5-2.5-4-2.5-4 5.5-1.5 6-11.5-5-15.5-11 4-10.5 14-5 15.5 0 0-2.5 1.5-2.5 4 0 0-.5.5 0 2z"/>
        <path d="M25 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 1 1 5 0z"/>
      </g>
      <path d="M17.5 26h10M15 30h15m-7.5-14.5v5M20 18h5" stroke="#fff" stroke-linejoin="miter"/>
    </g>
  </svg>`,
  bN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <g fill="none" fill-rule="evenodd" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22 10c10.5 1 16.5 8 16 29H15c0-9 10-6.5 8-21" fill="#000"/>
      <path d="M24 18c.38 2.91-5.55 7.37-8 9-3 2-2.82 4.34-5 4-1.042-.94 1.41-3.04 0-3-1 0 .19 1.23-1 2-1 0-4.003 1-4-4 0-2 6-12 6-12s1.89-1.9 2-3.5c-.73-.994-.5-2-.5-3 1-1 3 2.5 3 2.5h2s.78-1.992 2.5-3c1 0 1 3 1 3" fill="#000"/>
      <path d="M9.5 25.5a.5.5 0 1 1-1 0 .5.5 0 1 1 1 0z" fill="#fff" stroke="#fff"/>
      <path d="M15 15.5a.5 1.5 0 1 1-.5 0 .5 1.5 0 1 1 .5 0z" fill="#fff" stroke="#fff" transform="matrix(1 0 0 .99998 -2.798 1.03)"/>
      <path d="M24.55 10.4l-.45 1.45.5.15c3.15 1 5.65 2.49 7.9 6.75S35.75 29.06 35.25 39l-.05.5h2.25l.05-.5c.5-10.06-.88-16.85-3.25-21.34-2.37-4.49-5.79-6.64-9.19-7.16l-.51-.1z" fill="#fff" stroke="none"/>
    </g>
  </svg>`,
  bP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.5 9c-2.21 0-4 1.79-4 4 0 .89.29 1.71.78 2.38C17.33 16.5 16 18.59 16 21c0 2.03.94 3.84 2.41 5.03C15.41 27.09 11 31.58 11 39.5H34c0-7.92-4.41-12.41-7.41-13.47C28.06 24.84 29 23.03 29 21c0-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38 0-2.21-1.79-4-4-4z" fill="#000" stroke="#000" stroke-width="1.5" stroke-linecap="round"/>
  </svg>`,
};

// ===== ALPHA THEME =====
// Lichess-inspired geometric style with bold outlines
const alphaPieces: Record<string, string> = {
  wK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-wk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#e0e0e0"/></linearGradient></defs>
    <path d="M22.5 6v5M20 8.5h5" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M22.5 14c-2 0-3.5 2-3.5 4.5 0 2 1.5 5 3.5 8 2-3 3.5-6 3.5-8 0-2.5-1.5-4.5-3.5-4.5z" fill="url(#alpha-wk)" stroke="#333" stroke-width="1.5"/>
    <path d="M12 38h21v-6c0-3-2-5-5-6l2-4c-2-2-5-3-7.5-3s-5.5 1-7.5 3l2 4c-3 1-5 3-5 6v6z" fill="url(#alpha-wk)" stroke="#333" stroke-width="1.5"/>
    <path d="M14 32h17M14 35h17" stroke="#333" stroke-width="0.8" fill="none" opacity="0.3"/>
  </svg>`,
  wQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-wq" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#ddd"/></linearGradient></defs>
    <circle cx="8" cy="11" r="2.5" fill="url(#alpha-wq)" stroke="#333" stroke-width="1.2"/>
    <circle cx="15" cy="8" r="2.5" fill="url(#alpha-wq)" stroke="#333" stroke-width="1.2"/>
    <circle cx="22.5" cy="7" r="2.5" fill="url(#alpha-wq)" stroke="#333" stroke-width="1.2"/>
    <circle cx="30" cy="8" r="2.5" fill="url(#alpha-wq)" stroke="#333" stroke-width="1.2"/>
    <circle cx="37" cy="11" r="2.5" fill="url(#alpha-wq)" stroke="#333" stroke-width="1.2"/>
    <path d="M9 26c8-1.5 19-1.5 27 0l2-11-6.5 10V12l-5 12-3-13-3 13-5-12v13L9.5 15l1.5 11z" fill="url(#alpha-wq)" stroke="#333" stroke-width="1.5"/>
    <path d="M10 28c0 2 1.5 2.5 2.5 4 .5 1.5.5 2 0 3.5-1 .5-1.5 1.5-1.5 2.5 6 1 16 1 23 0 0-1-.5-2-1.5-2.5-.5-1.5-.5-2 0-3.5 1-1.5 2.5-2 2.5-4-8-1.5-18-1.5-25 0z" fill="url(#alpha-wq)" stroke="#333" stroke-width="1.5"/>
  </svg>`,
  wR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-wr" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#ddd"/></linearGradient></defs>
    <path d="M10 38h25v-3H10v3zM12 35v-5h21v5H12z" fill="url(#alpha-wr)" stroke="#333" stroke-width="1.5"/>
    <path d="M13 17v13h19V17H13z" fill="url(#alpha-wr)" stroke="#333" stroke-width="1.5"/>
    <path d="M13 14V8h5v3h4V8h5v3h4v6H13z" fill="url(#alpha-wr)" stroke="#333" stroke-width="1.5"/>
    <path d="M15 20h15" stroke="#333" stroke-width="0.5" opacity="0.3"/>
  </svg>`,
  wB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-wb" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#ddd"/></linearGradient></defs>
    <circle cx="22.5" cy="8" r="3" fill="url(#alpha-wb)" stroke="#333" stroke-width="1.5"/>
    <path d="M13 36c2-2 5-3 9.5-3s7.5 1 9.5 3c1-2 0-3-1-4 0-3-3-5-3-5 5-2 5-12-5.5-16-10.5 4-10.5 14-5.5 16 0 0-3 2-3 5-1 1-2 2-1 4z" fill="url(#alpha-wb)" stroke="#333" stroke-width="1.5"/>
    <path d="M17 26h11" stroke="#333" stroke-width="1.5"/>
    <path d="M22.5 17v6" stroke="#333" stroke-width="1.5"/>
  </svg>`,
  wN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-wn" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#ddd"/></linearGradient></defs>
    <path d="M16 38c0-8 8-8 8-18 0-4-1-7-3-9-1-1-1-3-1-4 1-1 3 1 3 1l2-2c1 0 2 2 2 2 3 1 6 4 7 8 2 5 2 12 2 20H16z" fill="url(#alpha-wn)" stroke="#333" stroke-width="1.5"/>
    <circle cx="17" cy="18" r="1.5" fill="#333"/>
    <path d="M13 22c-1 0-2 1-2 2s1 2 2 2" stroke="#333" stroke-width="1.2" fill="none"/>
  </svg>`,
  wP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-wp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#ddd"/></linearGradient></defs>
    <circle cx="22.5" cy="14" r="5" fill="url(#alpha-wp)" stroke="#333" stroke-width="1.5"/>
    <path d="M16 22c-3 3-5 7-5 16h23c0-9-2-13-5-16-2-1-4-2-6.5-2s-4.5 1-6.5 2z" fill="url(#alpha-wp)" stroke="#333" stroke-width="1.5"/>
  </svg>`,
  bK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-bk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#222"/></linearGradient></defs>
    <path d="M22.5 6v5M20 8.5h5" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M22.5 14c-2 0-3.5 2-3.5 4.5 0 2 1.5 5 3.5 8 2-3 3.5-6 3.5-8 0-2.5-1.5-4.5-3.5-4.5z" fill="url(#alpha-bk)" stroke="#111" stroke-width="1.5"/>
    <path d="M12 38h21v-6c0-3-2-5-5-6l2-4c-2-2-5-3-7.5-3s-5.5 1-7.5 3l2 4c-3 1-5 3-5 6v6z" fill="url(#alpha-bk)" stroke="#111" stroke-width="1.5"/>
    <path d="M14 32h17M14 35h17" stroke="#fff" stroke-width="0.8" fill="none" opacity="0.3"/>
  </svg>`,
  bQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-bq" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#222"/></linearGradient></defs>
    <circle cx="8" cy="11" r="2.5" fill="url(#alpha-bq)" stroke="#111" stroke-width="1.2"/>
    <circle cx="15" cy="8" r="2.5" fill="url(#alpha-bq)" stroke="#111" stroke-width="1.2"/>
    <circle cx="22.5" cy="7" r="2.5" fill="url(#alpha-bq)" stroke="#111" stroke-width="1.2"/>
    <circle cx="30" cy="8" r="2.5" fill="url(#alpha-bq)" stroke="#111" stroke-width="1.2"/>
    <circle cx="37" cy="11" r="2.5" fill="url(#alpha-bq)" stroke="#111" stroke-width="1.2"/>
    <path d="M9 26c8-1.5 19-1.5 27 0l2-11-6.5 10V12l-5 12-3-13-3 13-5-12v13L9.5 15l1.5 11z" fill="url(#alpha-bq)" stroke="#111" stroke-width="1.5"/>
    <path d="M10 28c0 2 1.5 2.5 2.5 4 .5 1.5.5 2 0 3.5-1 .5-1.5 1.5-1.5 2.5 6 1 16 1 23 0 0-1-.5-2-1.5-2.5-.5-1.5-.5-2 0-3.5 1-1.5 2.5-2 2.5-4-8-1.5-18-1.5-25 0z" fill="url(#alpha-bq)" stroke="#111" stroke-width="1.5"/>
  </svg>`,
  bR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-br" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#222"/></linearGradient></defs>
    <path d="M10 38h25v-3H10v3zM12 35v-5h21v5H12z" fill="url(#alpha-br)" stroke="#111" stroke-width="1.5"/>
    <path d="M13 17v13h19V17H13z" fill="url(#alpha-br)" stroke="#111" stroke-width="1.5"/>
    <path d="M13 14V8h5v3h4V8h5v3h4v6H13z" fill="url(#alpha-br)" stroke="#111" stroke-width="1.5"/>
  </svg>`,
  bB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-bb" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#222"/></linearGradient></defs>
    <circle cx="22.5" cy="8" r="3" fill="url(#alpha-bb)" stroke="#111" stroke-width="1.5"/>
    <path d="M13 36c2-2 5-3 9.5-3s7.5 1 9.5 3c1-2 0-3-1-4 0-3-3-5-3-5 5-2 5-12-5.5-16-10.5 4-10.5 14-5.5 16 0 0-3 2-3 5-1 1-2 2-1 4z" fill="url(#alpha-bb)" stroke="#111" stroke-width="1.5"/>
    <path d="M17 26h11" stroke="#fff" stroke-width="1.5" opacity="0.5"/>
    <path d="M22.5 17v6" stroke="#fff" stroke-width="1.5" opacity="0.5"/>
  </svg>`,
  bN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-bn" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#222"/></linearGradient></defs>
    <path d="M16 38c0-8 8-8 8-18 0-4-1-7-3-9-1-1-1-3-1-4 1-1 3 1 3 1l2-2c1 0 2 2 2 2 3 1 6 4 7 8 2 5 2 12 2 20H16z" fill="url(#alpha-bn)" stroke="#111" stroke-width="1.5"/>
    <circle cx="17" cy="18" r="1.5" fill="#fff"/>
    <path d="M13 22c-1 0-2 1-2 2s1 2 2 2" stroke="#fff" stroke-width="1.2" fill="none" opacity="0.5"/>
  </svg>`,
  bP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="alpha-bp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#555"/><stop offset="100%" stop-color="#222"/></linearGradient></defs>
    <circle cx="22.5" cy="14" r="5" fill="url(#alpha-bp)" stroke="#111" stroke-width="1.5"/>
    <path d="M16 22c-3 3-5 7-5 16h23c0-9-2-13-5-16-2-1-4-2-6.5-2s-4.5 1-6.5 2z" fill="url(#alpha-bp)" stroke="#111" stroke-width="1.5"/>
  </svg>`,
};

// ===== MODERN / FLAT THEME =====
// Minimalist flat design with bold colors and simple geometric shapes
const modernPieces: Record<string, string> = {
  wK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="30" width="25" height="8" rx="2" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <rect x="14" y="18" width="17" height="14" rx="2" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <rect x="20" y="6" width="5" height="14" rx="1" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <rect x="17" y="10" width="11" height="4" rx="1" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
  </svg>`,
  wQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="30" width="25" height="8" rx="2" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <polygon points="10,30 14,14 22.5,8 31,14 35,30" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <circle cx="10" cy="12" r="3" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <circle cx="22.5" cy="6" r="3" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <circle cx="35" cy="12" r="3" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
  </svg>`,
  wR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="30" width="25" height="8" rx="2" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <rect x="13" y="16" width="19" height="16" rx="1" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <rect x="11" y="8" width="5" height="10" rx="1" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <rect x="20" y="8" width="5" height="10" rx="1" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <rect x="29" y="8" width="5" height="10" rx="1" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
  </svg>`,
  wB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="32" width="25" height="6" rx="2" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <ellipse cx="22.5" cy="22" rx="8" ry="12" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <circle cx="22.5" cy="8" r="3.5" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <line x1="18" y1="22" x2="27" y2="22" stroke="#444" stroke-width="1.5"/>
  </svg>`,
  wN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="32" width="25" height="6" rx="2" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <path d="M15 32 L15 18 Q15 10 22 8 L28 12 Q32 16 32 22 L32 32 Z" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <circle cx="19" cy="16" r="2" fill="#444"/>
  </svg>`,
  wP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <circle cx="22.5" cy="14" r="6" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
    <path d="M15 38 Q15 24 22.5 22 Q30 24 30 38 Z" fill="#f5f5f5" stroke="#444" stroke-width="1.5"/>
  </svg>`,
  bK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="30" width="25" height="8" rx="2" fill="#333" stroke="#111" stroke-width="1.5"/>
    <rect x="14" y="18" width="17" height="14" rx="2" fill="#333" stroke="#111" stroke-width="1.5"/>
    <rect x="20" y="6" width="5" height="14" rx="1" fill="#333" stroke="#111" stroke-width="1.5"/>
    <rect x="17" y="10" width="11" height="4" rx="1" fill="#333" stroke="#111" stroke-width="1.5"/>
  </svg>`,
  bQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="30" width="25" height="8" rx="2" fill="#333" stroke="#111" stroke-width="1.5"/>
    <polygon points="10,30 14,14 22.5,8 31,14 35,30" fill="#333" stroke="#111" stroke-width="1.5"/>
    <circle cx="10" cy="12" r="3" fill="#333" stroke="#111" stroke-width="1.5"/>
    <circle cx="22.5" cy="6" r="3" fill="#333" stroke="#111" stroke-width="1.5"/>
    <circle cx="35" cy="12" r="3" fill="#333" stroke="#111" stroke-width="1.5"/>
  </svg>`,
  bR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="30" width="25" height="8" rx="2" fill="#333" stroke="#111" stroke-width="1.5"/>
    <rect x="13" y="16" width="19" height="16" rx="1" fill="#333" stroke="#111" stroke-width="1.5"/>
    <rect x="11" y="8" width="5" height="10" rx="1" fill="#333" stroke="#111" stroke-width="1.5"/>
    <rect x="20" y="8" width="5" height="10" rx="1" fill="#333" stroke="#111" stroke-width="1.5"/>
    <rect x="29" y="8" width="5" height="10" rx="1" fill="#333" stroke="#111" stroke-width="1.5"/>
  </svg>`,
  bB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="32" width="25" height="6" rx="2" fill="#333" stroke="#111" stroke-width="1.5"/>
    <ellipse cx="22.5" cy="22" rx="8" ry="12" fill="#333" stroke="#111" stroke-width="1.5"/>
    <circle cx="22.5" cy="8" r="3.5" fill="#333" stroke="#111" stroke-width="1.5"/>
    <line x1="18" y1="22" x2="27" y2="22" stroke="#888" stroke-width="1.5"/>
  </svg>`,
  bN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <rect x="10" y="32" width="25" height="6" rx="2" fill="#333" stroke="#111" stroke-width="1.5"/>
    <path d="M15 32 L15 18 Q15 10 22 8 L28 12 Q32 16 32 22 L32 32 Z" fill="#333" stroke="#111" stroke-width="1.5"/>
    <circle cx="19" cy="16" r="2" fill="#ddd"/>
  </svg>`,
  bP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <circle cx="22.5" cy="14" r="6" fill="#333" stroke="#111" stroke-width="1.5"/>
    <path d="M15 38 Q15 24 22.5 22 Q30 24 30 38 Z" fill="#333" stroke="#111" stroke-width="1.5"/>
  </svg>`,
};

// ===== WOOD / STAUNTON THEME =====
// Traditional ornate tournament style with warm tones
const woodPieces: Record<string, string> = {
  wK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-wk" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fff8e8"/><stop offset="50%" stop-color="#f5e6c8"/><stop offset="100%" stop-color="#e8d4a8"/></linearGradient></defs>
    <path d="M22.5 5v3M20.5 7h4" stroke="#5a3e1b" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M22.5 12c-1.5 0-2.5 1-3 2.5-.5 1.5 0 3 1 4.5.5 1 1.5 2.5 2 3.5.5-1 1.5-2.5 2-3.5 1-1.5 1.5-3 1-4.5-.5-1.5-1.5-2.5-3-2.5z" fill="url(#wood-wk)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M14 38c0-2 1-3 2-4 1.5-1.5 2-3 2-5 0-1-.5-2-1-3-1-1.5-1.5-3-1.5-4.5 0-2 1.5-3.5 3.5-4h7c2 .5 3.5 2 3.5 4 0 1.5-.5 3-1.5 4.5-.5 1-1 2-1 3 0 2 .5 3.5 2 5 1 1 2 2 2 4H14z" fill="url(#wood-wk)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M16 34c4-1.5 10-1.5 13 0M15 36c5-1.5 11-1.5 15 0" stroke="#5a3e1b" stroke-width="0.8" fill="none" opacity="0.4"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-wk)" stroke="#5a3e1b" stroke-width="1.2"/>
  </svg>`,
  wQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-wq" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fff8e8"/><stop offset="50%" stop-color="#f5e6c8"/><stop offset="100%" stop-color="#e8d4a8"/></linearGradient></defs>
    <circle cx="8" cy="10" r="2.5" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1"/>
    <circle cx="15" cy="7" r="2.5" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1"/>
    <circle cx="22.5" cy="6" r="2.5" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1"/>
    <circle cx="30" cy="7" r="2.5" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1"/>
    <circle cx="37" cy="10" r="2.5" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1"/>
    <path d="M8 26c9-2 20-2 29 0l3-14-7 12V10l-6 14-3-16-3 16-6-14v14l-7-12 3 14z" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M10 28c0 2 2 3 3 4.5.5 1.5 0 2.5-1 3.5 7 1.5 16 1.5 23 0-1-1-1.5-2-1-3.5 1-1.5 3-2.5 3-4.5-9-2-19-2-27 0z" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1.2"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-wq)" stroke="#5a3e1b" stroke-width="1.2"/>
  </svg>`,
  wR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-wr" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fff8e8"/><stop offset="50%" stop-color="#f5e6c8"/><stop offset="100%" stop-color="#e8d4a8"/></linearGradient></defs>
    <path d="M9 38h27v-3H9v3zM11 35v-4h23v4H11z" fill="url(#wood-wr)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M13 16v15h19V16H13z" fill="url(#wood-wr)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M13 13V7h5v3h4V7h5v3h5V7h5v6H13z" fill="url(#wood-wr)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M15 19h15M15 23h15" stroke="#5a3e1b" stroke-width="0.6" fill="none" opacity="0.3"/>
    <ellipse cx="22.5" cy="38" rx="11" ry="2" fill="url(#wood-wr)" stroke="#5a3e1b" stroke-width="1.2"/>
  </svg>`,
  wB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-wb" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fff8e8"/><stop offset="50%" stop-color="#f5e6c8"/><stop offset="100%" stop-color="#e8d4a8"/></linearGradient></defs>
    <circle cx="22.5" cy="7" r="3" fill="url(#wood-wb)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M12 36c2-2 5-3 10.5-3s8.5 1 10.5 3c1.5-2 0-3.5-1-4.5 0-3-3-5.5-3-5.5 6-2 5.5-13-6.5-17-12 4-12.5 15-6.5 17 0 0-3 2.5-3 5.5-1 1-2.5 2.5-1 4.5z" fill="url(#wood-wb)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M16 26h13" stroke="#5a3e1b" stroke-width="1.5"/>
    <path d="M22.5 16v7" stroke="#5a3e1b" stroke-width="1.5"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-wb)" stroke="#5a3e1b" stroke-width="1.2"/>
  </svg>`,
  wN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-wn" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fff8e8"/><stop offset="50%" stop-color="#f5e6c8"/><stop offset="100%" stop-color="#e8d4a8"/></linearGradient></defs>
    <path d="M14 38c0-8 7-7 7-17 0-4-1-7-3-9-1-1-1.5-3-1-4 1-1 3 1 3 1l2.5-2c1.5 0 2 2.5 2 2.5 3 1 6 4 7 8 2 5 2 12 2 19H14z" fill="url(#wood-wn)" stroke="#5a3e1b" stroke-width="1.2"/>
    <circle cx="16" cy="17" r="1.5" fill="#5a3e1b"/>
    <path d="M12 21c-1.5 0-2.5 1-2.5 2.5s1 2.5 2.5 2.5" stroke="#5a3e1b" stroke-width="1.2" fill="none"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-wn)" stroke="#5a3e1b" stroke-width="1.2"/>
  </svg>`,
  wP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-wp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff8e8"/><stop offset="100%" stop-color="#e8d4a8"/></linearGradient></defs>
    <circle cx="22.5" cy="13" r="5.5" fill="url(#wood-wp)" stroke="#5a3e1b" stroke-width="1.2"/>
    <path d="M15 22c-3 3-5 7-5 16h25c0-9-2-13-5-16-2-1.5-4.5-2.5-7.5-2.5S17 20.5 15 22z" fill="url(#wood-wp)" stroke="#5a3e1b" stroke-width="1.2"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-wp)" stroke="#5a3e1b" stroke-width="1.2"/>
  </svg>`,
  bK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-bk" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#6b4423"/><stop offset="50%" stop-color="#4a2f14"/><stop offset="100%" stop-color="#3a2210"/></linearGradient></defs>
    <path d="M22.5 5v3M20.5 7h4" stroke="#d4a86a" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M22.5 12c-1.5 0-2.5 1-3 2.5-.5 1.5 0 3 1 4.5.5 1 1.5 2.5 2 3.5.5-1 1.5-2.5 2-3.5 1-1.5 1.5-3 1-4.5-.5-1.5-1.5-2.5-3-2.5z" fill="url(#wood-bk)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M14 38c0-2 1-3 2-4 1.5-1.5 2-3 2-5 0-1-.5-2-1-3-1-1.5-1.5-3-1.5-4.5 0-2 1.5-3.5 3.5-4h7c2 .5 3.5 2 3.5 4 0 1.5-.5 3-1.5 4.5-.5 1-1 2-1 3 0 2 .5 3.5 2 5 1 1 2 2 2 4H14z" fill="url(#wood-bk)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M16 34c4-1.5 10-1.5 13 0M15 36c5-1.5 11-1.5 15 0" stroke="#d4a86a" stroke-width="0.8" fill="none" opacity="0.3"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-bk)" stroke="#2a1808" stroke-width="1.2"/>
  </svg>`,
  bQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-bq" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#6b4423"/><stop offset="50%" stop-color="#4a2f14"/><stop offset="100%" stop-color="#3a2210"/></linearGradient></defs>
    <circle cx="8" cy="10" r="2.5" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1"/>
    <circle cx="15" cy="7" r="2.5" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1"/>
    <circle cx="22.5" cy="6" r="2.5" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1"/>
    <circle cx="30" cy="7" r="2.5" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1"/>
    <circle cx="37" cy="10" r="2.5" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1"/>
    <path d="M8 26c9-2 20-2 29 0l3-14-7 12V10l-6 14-3-16-3 16-6-14v14l-7-12 3 14z" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M10 28c0 2 2 3 3 4.5.5 1.5 0 2.5-1 3.5 7 1.5 16 1.5 23 0-1-1-1.5-2-1-3.5 1-1.5 3-2.5 3-4.5-9-2-19-2-27 0z" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1.2"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-bq)" stroke="#2a1808" stroke-width="1.2"/>
  </svg>`,
  bR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-br" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#6b4423"/><stop offset="50%" stop-color="#4a2f14"/><stop offset="100%" stop-color="#3a2210"/></linearGradient></defs>
    <path d="M9 38h27v-3H9v3zM11 35v-4h23v4H11z" fill="url(#wood-br)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M13 16v15h19V16H13z" fill="url(#wood-br)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M13 13V7h5v3h4V7h5v3h5V7h5v6H13z" fill="url(#wood-br)" stroke="#2a1808" stroke-width="1.2"/>
    <ellipse cx="22.5" cy="38" rx="11" ry="2" fill="url(#wood-br)" stroke="#2a1808" stroke-width="1.2"/>
  </svg>`,
  bB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-bb" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#6b4423"/><stop offset="50%" stop-color="#4a2f14"/><stop offset="100%" stop-color="#3a2210"/></linearGradient></defs>
    <circle cx="22.5" cy="7" r="3" fill="url(#wood-bb)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M12 36c2-2 5-3 10.5-3s8.5 1 10.5 3c1.5-2 0-3.5-1-4.5 0-3-3-5.5-3-5.5 6-2 5.5-13-6.5-17-12 4-12.5 15-6.5 17 0 0-3 2.5-3 5.5-1 1-2.5 2.5-1 4.5z" fill="url(#wood-bb)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M16 26h13" stroke="#d4a86a" stroke-width="1.5" opacity="0.5"/>
    <path d="M22.5 16v7" stroke="#d4a86a" stroke-width="1.5" opacity="0.5"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-bb)" stroke="#2a1808" stroke-width="1.2"/>
  </svg>`,
  bN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-bn" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#6b4423"/><stop offset="50%" stop-color="#4a2f14"/><stop offset="100%" stop-color="#3a2210"/></linearGradient></defs>
    <path d="M14 38c0-8 7-7 7-17 0-4-1-7-3-9-1-1-1.5-3-1-4 1-1 3 1 3 1l2.5-2c1.5 0 2 2.5 2 2.5 3 1 6 4 7 8 2 5 2 12 2 19H14z" fill="url(#wood-bn)" stroke="#2a1808" stroke-width="1.2"/>
    <circle cx="16" cy="17" r="1.5" fill="#d4a86a"/>
    <path d="M12 21c-1.5 0-2.5 1-2.5 2.5s1 2.5 2.5 2.5" stroke="#d4a86a" stroke-width="1.2" fill="none" opacity="0.5"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-bn)" stroke="#2a1808" stroke-width="1.2"/>
  </svg>`,
  bP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="wood-bp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#6b4423"/><stop offset="100%" stop-color="#3a2210"/></linearGradient></defs>
    <circle cx="22.5" cy="13" r="5.5" fill="url(#wood-bp)" stroke="#2a1808" stroke-width="1.2"/>
    <path d="M15 22c-3 3-5 7-5 16h25c0-9-2-13-5-16-2-1.5-4.5-2.5-7.5-2.5S17 20.5 15 22z" fill="url(#wood-bp)" stroke="#2a1808" stroke-width="1.2"/>
    <ellipse cx="22.5" cy="38" rx="10" ry="2" fill="url(#wood-bp)" stroke="#2a1808" stroke-width="1.2"/>
  </svg>`,
};

// ===== GOTHIC / FANTASY THEME =====
// Sharp, stylized dramatic silhouettes with angular edges
const gothicPieces: Record<string, string> = {
  wK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-wk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f8f8ff"/><stop offset="100%" stop-color="#c8c8d8"/></linearGradient></defs>
    <path d="M22.5 3L20 7h5L22.5 3z" fill="url(#goth-wk)" stroke="#222" stroke-width="1"/>
    <path d="M22.5 7v4" stroke="#222" stroke-width="2"/>
    <path d="M18 11l4.5 6 4.5-6c2 1 3 3 3 5.5 0 3-2 6-3.5 8L22.5 28l-3.5-3.5C17.5 22.5 15.5 19.5 15.5 16.5c0-2.5 1-4.5 2.5-5.5z" fill="url(#goth-wk)" stroke="#222" stroke-width="1.2"/>
    <path d="M10 38l2-8-3-4 5-2-1-4h19l-1 4 5 2-3 4 2 8H10z" fill="url(#goth-wk)" stroke="#222" stroke-width="1.2"/>
    <path d="M14 34l16 0M12 36l18 0" stroke="#222" stroke-width="0.5" opacity="0.3"/>
  </svg>`,
  wQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-wq" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f8f8ff"/><stop offset="100%" stop-color="#c8c8d8"/></linearGradient></defs>
    <path d="M7 8l2 4 3-5 3 5 3.5-6 4 6 3.5-6 3 5 3-5 2 4-3 12h-24L7 8z" fill="url(#goth-wq)" stroke="#222" stroke-width="1.2"/>
    <circle cx="7" cy="7" r="2" fill="url(#goth-wq)" stroke="#222" stroke-width="1"/>
    <circle cx="15" cy="5" r="2" fill="url(#goth-wq)" stroke="#222" stroke-width="1"/>
    <circle cx="22.5" cy="4" r="2" fill="url(#goth-wq)" stroke="#222" stroke-width="1"/>
    <circle cx="30" cy="5" r="2" fill="url(#goth-wq)" stroke="#222" stroke-width="1"/>
    <circle cx="38" cy="7" r="2" fill="url(#goth-wq)" stroke="#222" stroke-width="1"/>
    <path d="M9 22c8-1.5 19-1.5 27 0l1 4c-8 1.5-19 1.5-27 0l-1-4z" fill="url(#goth-wq)" stroke="#222" stroke-width="1.2"/>
    <path d="M10 28l2-2h21l2 2-1 4H11l-1-4z" fill="url(#goth-wq)" stroke="#222" stroke-width="1.2"/>
    <path d="M8 34l2-2h25l2 2v4H8v-4z" fill="url(#goth-wq)" stroke="#222" stroke-width="1.2"/>
  </svg>`,
  wR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-wr" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f8f8ff"/><stop offset="100%" stop-color="#c8c8d8"/></linearGradient></defs>
    <path d="M9 38h27l-1-4H10l-1 4z" fill="url(#goth-wr)" stroke="#222" stroke-width="1.2"/>
    <path d="M11 34l1-3h21l1 3H11z" fill="url(#goth-wr)" stroke="#222" stroke-width="1.2"/>
    <path d="M13 14v17h19V14H13z" fill="url(#goth-wr)" stroke="#222" stroke-width="1.2"/>
    <path d="M11 6v8h4V9h3v5h4V9h3v5h4V9h3v5h4V6H11z" fill="url(#goth-wr)" stroke="#222" stroke-width="1.2"/>
  </svg>`,
  wB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-wb" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f8f8ff"/><stop offset="100%" stop-color="#c8c8d8"/></linearGradient></defs>
    <path d="M22.5 4l-2 4h4l-2-4z" fill="url(#goth-wb)" stroke="#222" stroke-width="1"/>
    <circle cx="22.5" cy="10" r="3" fill="url(#goth-wb)" stroke="#222" stroke-width="1.2"/>
    <path d="M14 36l2-6-2-4 4-2-1-4c2-4 4-8 5.5-10 1.5 2 3.5 6 5.5 10l-1 4 4 2-2 4 2 6H14z" fill="url(#goth-wb)" stroke="#222" stroke-width="1.2"/>
    <path d="M17 24h11" stroke="#222" stroke-width="1.5"/>
    <path d="M22.5 15v6" stroke="#222" stroke-width="1.5"/>
  </svg>`,
  wN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-wn" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f8f8ff"/><stop offset="100%" stop-color="#c8c8d8"/></linearGradient></defs>
    <path d="M12 38l2-4-1-3 3-2V22l-2-4 3-3-1-3 3-3 2 1 1-3 3 2 2 4c1 2 2 5 2 8v10l3 2-1 3 2 4H12z" fill="url(#goth-wn)" stroke="#222" stroke-width="1.2"/>
    <circle cx="17" cy="15" r="1.5" fill="#222"/>
    <path d="M13 20l-2 1 1 2" stroke="#222" stroke-width="1" fill="none"/>
  </svg>`,
  wP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-wp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f8f8ff"/><stop offset="100%" stop-color="#c8c8d8"/></linearGradient></defs>
    <path d="M22.5 7l-3 5 1 2-2 2 1 3c-3 2-5 5-5 10v9h16v-9c0-5-2-8-5-10l1-3-2-2 1-2-3-5z" fill="url(#goth-wp)" stroke="#222" stroke-width="1.2"/>
  </svg>`,
  bK: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-bk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#444"/><stop offset="100%" stop-color="#111"/></linearGradient></defs>
    <path d="M22.5 3L20 7h5L22.5 3z" fill="url(#goth-bk)" stroke="#000" stroke-width="1"/>
    <path d="M22.5 7v4" stroke="#ddd" stroke-width="2"/>
    <path d="M18 11l4.5 6 4.5-6c2 1 3 3 3 5.5 0 3-2 6-3.5 8L22.5 28l-3.5-3.5C17.5 22.5 15.5 19.5 15.5 16.5c0-2.5 1-4.5 2.5-5.5z" fill="url(#goth-bk)" stroke="#000" stroke-width="1.2"/>
    <path d="M10 38l2-8-3-4 5-2-1-4h19l-1 4 5 2-3 4 2 8H10z" fill="url(#goth-bk)" stroke="#000" stroke-width="1.2"/>
    <path d="M14 34l16 0M12 36l18 0" stroke="#ddd" stroke-width="0.5" opacity="0.3"/>
  </svg>`,
  bQ: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-bq" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#444"/><stop offset="100%" stop-color="#111"/></linearGradient></defs>
    <path d="M7 8l2 4 3-5 3 5 3.5-6 4 6 3.5-6 3 5 3-5 2 4-3 12h-24L7 8z" fill="url(#goth-bq)" stroke="#000" stroke-width="1.2"/>
    <circle cx="7" cy="7" r="2" fill="url(#goth-bq)" stroke="#000" stroke-width="1"/>
    <circle cx="15" cy="5" r="2" fill="url(#goth-bq)" stroke="#000" stroke-width="1"/>
    <circle cx="22.5" cy="4" r="2" fill="url(#goth-bq)" stroke="#000" stroke-width="1"/>
    <circle cx="30" cy="5" r="2" fill="url(#goth-bq)" stroke="#000" stroke-width="1"/>
    <circle cx="38" cy="7" r="2" fill="url(#goth-bq)" stroke="#000" stroke-width="1"/>
    <path d="M9 22c8-1.5 19-1.5 27 0l1 4c-8 1.5-19 1.5-27 0l-1-4z" fill="url(#goth-bq)" stroke="#000" stroke-width="1.2"/>
    <path d="M10 28l2-2h21l2 2-1 4H11l-1-4z" fill="url(#goth-bq)" stroke="#000" stroke-width="1.2"/>
    <path d="M8 34l2-2h25l2 2v4H8v-4z" fill="url(#goth-bq)" stroke="#000" stroke-width="1.2"/>
  </svg>`,
  bR: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-br" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#444"/><stop offset="100%" stop-color="#111"/></linearGradient></defs>
    <path d="M9 38h27l-1-4H10l-1 4z" fill="url(#goth-br)" stroke="#000" stroke-width="1.2"/>
    <path d="M11 34l1-3h21l1 3H11z" fill="url(#goth-br)" stroke="#000" stroke-width="1.2"/>
    <path d="M13 14v17h19V14H13z" fill="url(#goth-br)" stroke="#000" stroke-width="1.2"/>
    <path d="M11 6v8h4V9h3v5h4V9h3v5h4V9h3v5h4V6H11z" fill="url(#goth-br)" stroke="#000" stroke-width="1.2"/>
  </svg>`,
  bB: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-bb" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#444"/><stop offset="100%" stop-color="#111"/></linearGradient></defs>
    <path d="M22.5 4l-2 4h4l-2-4z" fill="url(#goth-bb)" stroke="#000" stroke-width="1"/>
    <circle cx="22.5" cy="10" r="3" fill="url(#goth-bb)" stroke="#000" stroke-width="1.2"/>
    <path d="M14 36l2-6-2-4 4-2-1-4c2-4 4-8 5.5-10 1.5 2 3.5 6 5.5 10l-1 4 4 2-2 4 2 6H14z" fill="url(#goth-bb)" stroke="#000" stroke-width="1.2"/>
    <path d="M17 24h11" stroke="#ddd" stroke-width="1.5" opacity="0.5"/>
    <path d="M22.5 15v6" stroke="#ddd" stroke-width="1.5" opacity="0.5"/>
  </svg>`,
  bN: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-bn" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#444"/><stop offset="100%" stop-color="#111"/></linearGradient></defs>
    <path d="M12 38l2-4-1-3 3-2V22l-2-4 3-3-1-3 3-3 2 1 1-3 3 2 2 4c1 2 2 5 2 8v10l3 2-1 3 2 4H12z" fill="url(#goth-bn)" stroke="#000" stroke-width="1.2"/>
    <circle cx="17" cy="15" r="1.5" fill="#ddd"/>
    <path d="M13 20l-2 1 1 2" stroke="#ddd" stroke-width="1" fill="none" opacity="0.5"/>
  </svg>`,
  bP: `<svg viewBox="0 0 45 45" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="goth-bp" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#444"/><stop offset="100%" stop-color="#111"/></linearGradient></defs>
    <path d="M22.5 7l-3 5 1 2-2 2 1 3c-3 2-5 5-5 10v9h16v-9c0-5-2-8-5-10l1-3-2-2 1-2-3-5z" fill="url(#goth-bp)" stroke="#000" stroke-width="1.2"/>
  </svg>`,
};

// ===== THEME COLLECTION =====
export const PIECE_THEMES: Record<PieceTheme, Record<string, string>> = {
  classic: classicPieces,
  alpha: alphaPieces,
  modern: modernPieces,
  wood: woodPieces,
  gothic: gothicPieces,
};

export const PIECE_THEME_INFO: PieceThemeInfo[] = [
  {
    id: 'classic',
    name: 'Classic',
    description: 'Clean, standard tournament style',
    preview: classicPieces.wK,
  },
  {
    id: 'alpha',
    name: 'Alpha',
    description: 'Lichess-inspired geometric style',
    preview: alphaPieces.wK,
  },
  {
    id: 'modern',
    name: 'Modern',
    description: 'Minimalist flat design',
    preview: modernPieces.wK,
  },
  {
    id: 'wood',
    name: 'Staunton',
    description: 'Traditional warm tournament style',
    preview: woodPieces.wK,
  },
  {
    id: 'gothic',
    name: 'Gothic',
    description: 'Stylized sharp silhouettes',
    preview: gothicPieces.wK,
  },
];

// Helper to get SVG string for a piece
export function getPieceSvg(theme: PieceTheme, color: 'w' | 'b', type: string): string {
  const key = `${color}${type.toUpperCase()}`;
  return PIECE_THEMES[theme]?.[key] || PIECE_THEMES.classic[key] || '';
}

// Default piece theme
export const DEFAULT_PIECE_THEME: PieceTheme = 'classic';

// LocalStorage key
export const PIECE_THEME_STORAGE_KEY = 'maitrey-chess-piece-theme';

// Load saved piece theme
export function loadPieceTheme(): PieceTheme {
  try {
    const saved = localStorage.getItem(PIECE_THEME_STORAGE_KEY);
    if (saved && saved in PIECE_THEMES) {
      return saved as PieceTheme;
    }
  } catch {
    // localStorage not available
  }
  return DEFAULT_PIECE_THEME;
}

// Save piece theme
export function savePieceTheme(theme: PieceTheme): void {
  try {
    localStorage.setItem(PIECE_THEME_STORAGE_KEY, theme);
  } catch {
    // localStorage not available
  }
}
