// Maitrey Chess GUI Pro - Type Definitions

export interface EngineSettings {
  depth: number;
  threads: number;
  hash: number;
  multiPV: number;
  skillLevel: number;
  uciElo: number;
  infiniteAnalysis: boolean;
}

export interface EngineInfo {
  depth: number;
  score: number;
  isMate: boolean;
  mateIn: number;
  nodes: number;
  nps: number;
  time: number;
  pv: string[];
  multiPV: MultiPVLine[];
  wdl: { w: number; d: number; l: number } | null;
}

export interface MultiPVLine {
  pv: string[];
  score: number;
  isMate: boolean;
  mateIn: number;
}

export interface GameHeaders {
  white: string;
  black: string;
  event: string;
  date: string;
  result: string;
  eco: string;
  opening: string;
}

export interface StudentProfile {
  id: string;
  name: string;
  age: number;
  rating: number;
  puzzleRating: number;
  progress: number[];
  openingsLearned: string[];
}

export interface ThemeColors {
  lightSquare: string;
  darkSquare: string;
  background: string;
  panelBg: string;
  text: string;
  accent: string;
  highlight: string;
  lastMove: string;
  check: string;
}

export interface PuzzleData {
  fen: string;
  moves: string[];
  rating: number;
  category: string;
  hint: string;
}

export type MoveClassification = 
  | 'brilliant'
  | 'great'
  | 'best'
  | 'excellent'
  | 'good'
  | 'book'
  | 'inaccuracy'
  | 'mistake'
  | 'blunder'
  | 'missed_win';

export interface MoveAnalysis {
  san: string;
  classification: MoveClassification;
  evalBefore: number;
  evalAfter: number;
  bestMove: string;
}

export interface OpeningEntry {
  eco: string;
  name: string;
  moves: string;
  fen: string;
}

export type BoardTheme = 'wood' | 'green' | 'blue' | 'marble' | 'tournament' | 'dark' | 'light';
